# 📚 Sistem Perpustakaan Digital

Sistem manajemen perpustakaan modern yang dibangun dengan PHP native, MySQL, dan teknologi web terkini. Dilengkapi dengan interface yang responsif menggunakan TailwindCSS dan interaksi yang intuitif dengan SweetAlert2.

## ✨ Fitur Unggulan

### 🔐 Sistem Autentikasi Lengkap

- Login dan registrasi dengan validasi keamanan
- Sistem role-based access (Admin/User)
- Session management yang aman
- Password hashing untuk keamanan data

### 👨‍💼 Panel Admin Komprehensif

- **📊 Dashboard Analytics**: Statistik real-time perpustakaan
- **📖 Manajemen Buku**: CRUD lengkap dengan pencarian dan filter
- **👥 Manajemen User**: Kelola pengguna, ubah role, dan monitoring aktivitas
- **📋 Manajemen Peminjaman**: Tracking lengkap semua transaksi peminjaman
- **🚨 SweetAlert Notifications**: Konfirmasi interaktif untuk semua aksi
- **📄 Export & Print**: Laporan yang dapat dicetak

### 👤 Dashboard User Interaktif

- **🏠 Dashboard Personal**: Overview peminjaman dan profil
- **🔍 Pencarian Buku**: Pencarian real-time berdasarkan judul/penulis
- **📚 Peminjaman Buku**: Sistem peminjaman dengan modal konfirmasi
- **📋 Riwayat Peminjaman**: Track semua aktivitas peminjaman
- **👤 Manajemen Profil**: Update username, email, dan password
- **💰 Tracking Denda**: Monitor denda dan status pembayaran

### 🎨 User Experience Modern

- **🎯 Responsive Design**: Optimal di desktop, tablet, dan mobile
- **🚀 SweetAlert2 Integration**: Modal dan notifikasi yang elegan
- **⚡ Real-time Updates**: Status update otomatis
- **🎨 TailwindCSS Styling**: Design yang modern dan konsisten
- **📱 Mobile-Friendly**: Navigasi yang mudah di semua perangkat

## 🛠️ Teknologi yang Digunakan

### Backend

- **PHP 7.4+**: Server-side scripting
- **MySQL 5.7+**: Database management system
- **Apache**: Web server

### Frontend

- **HTML5**: Markup structure
- **TailwindCSS**: Utility-first CSS framework
- **JavaScript ES6+**: Client-side interactivity
- **SweetAlert2**: Beautiful modal dialogs

### Tools & Libraries

- **XAMPP**: Local development environment
- **PDO/MySQLi**: Database connectivity
- **Session Management**: User authentication
- **Responsive Design**: Mobile-first approach

## 💻 Persyaratan Sistem

- **XAMPP** (Apache + MySQL + PHP) versi terbaru
- **PHP 7.4** atau lebih tinggi
- **MySQL 5.7** atau lebih tinggi
- **Web browser** modern (Chrome, Firefox, Safari, Edge)
- **RAM** minimal 2GB
- **Storage** minimal 100MB free space

## 🚀 Instalasi & Setup

### 1. 📥 Setup XAMPP

1. **Download XAMPP** dari [https://www.apachefriends.org/](https://www.apachefriends.org/)
2. **Install XAMPP** dengan mengikuti wizard
3. **Jalankan XAMPP Control Panel**
4. **Start Apache dan MySQL**

### 2. 🗄️ Setup Database

1. Buka **phpMyAdmin** di browser: `http://localhost/phpmyadmin`
2. Klik **"New"** untuk membuat database baru
3. Beri nama database: `perpustakaan`
4. Import file **`database.sql`** atau jalankan script SQL:

```sql
CREATE DATABASE perpustakaan;
USE perpustakaan;

-- Jalankan semua script dari database.sql
```

### 3. 📁 Setup Files

1. **Clone atau download** project ini
2. **Copy folder** `perpustakaan` ke dalam `c:\xampp\htdocs\`
3. Pastikan struktur folder seperti ini:

```
c:\xampp\htdocs\perpustakaan\
├── 📁 admin/
│   ├── 📄 dashboard.php
│   ├── 📄 books.php
│   ├── 📄 borrowings.php
│   └── 📄 users.php
├── 📁 user/
│   ├── 📄 dashboard.php
│   ├── 📄 borrowings.php
│   └── 📄 profile.php
├── ⚙️ config.php
├── 🏠 index.php
├── 🔐 login.php
├── 📝 register.php
├── 🚪 logout.php
├── 🎨 style-tailwind.css
├── 🎨 style.css
├── 🗃️ database.sql
└── 📖 README.md
```

### 4. ⚙️ Konfigurasi Database

1. Buka file **`config.php`**
2. Sesuaikan pengaturan database:

```php
<?php
$servername = "localhost";
$username = "root";           // Username MySQL
$password = "";               // Password MySQL (kosong untuk XAMPP default)
$database = "perpustakaan";   // Nama database
```

## 🎯 Cara Menggunakan

### 1. 🌐 Akses Website

- Buka browser dan kunjungi: **`http://localhost/perpustakaan`**
- Anda akan diarahkan ke halaman login yang elegan

### 2. 👨‍💼 Login sebagai Admin

**Akun Admin Default:**

- **Username**: `admin`
- **Password**: `admin123`

**Fitur Admin:**

- 📊 **Dashboard**: Statistik lengkap perpustakaan
- 📖 **Kelola Buku**: Tambah, edit, hapus buku dengan konfirmasi SweetAlert
- 👥 **Kelola User**: Manajemen pengguna dengan role management
- 📋 **Kelola Peminjaman**: Monitoring semua transaksi peminjaman

### 3. 📝 Registrasi User Baru

- Klik **"Daftar di sini"** di halaman login
- Isi form registrasi lengkap
- User baru otomatis mendapat role "User"
- Admin dapat mengubah role melalui panel admin

### 4. 👤 Dashboard User

**Fitur User:**

- 🏠 **Dashboard**: Browse dan cari buku
- 📚 **Peminjaman**: Pinjam buku dengan modal konfirmasi
- 📋 **Riwayat**: Lihat semua peminjaman dan status
- 👤 **Profil**: Update data personal (username, email, password)
- 💰 **Denda**: Monitor denda yang belum dibayar

### 5. 🔍 Fitur Pencarian

- **Pencarian Real-time**: Ketik dan lihat hasil langsung
- **Filter Multi-field**: Cari berdasarkan judul, penulis, atau ISBN
- **Status Ketersediaan**: Lihat stock dan status peminjaman

## 📊 Database Schema

### 📑 Tabel `users`

```sql
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    role ENUM('user', 'admin') DEFAULT 'user',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

### 📚 Tabel `books`

```sql
CREATE TABLE books (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    author VARCHAR(255) NOT NULL,
    isbn VARCHAR(20) UNIQUE,
    publisher VARCHAR(255),
    year_published YEAR,
    stock INT DEFAULT 1,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
```

### 📋 Tabel `borrowings`

```sql
CREATE TABLE borrowings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    book_id INT NOT NULL,
    borrow_date DATE NOT NULL,
    due_date DATE NOT NULL,
    return_date DATE NULL,
    status ENUM('borrowed', 'returned', 'overdue') DEFAULT 'borrowed',
    fine_amount DECIMAL(10,2) DEFAULT 0.00,
    fine_paid BOOLEAN DEFAULT FALSE,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (book_id) REFERENCES books(id) ON DELETE CASCADE
);
```

## Aturan Peminjaman

### Untuk User:

- Maksimal 3 buku dapat dipinjam per user
- Setiap buku dipinjam untuk jangka waktu 7 hari
- User tidak dapat meminjam buku yang sama jika masih dalam status dipinjam
- User yang memiliki buku terlambat tidak dapat meminjam buku baru
- User dapat mengembalikan buku kapan saja sebelum atau setelah jatuh tempo

### Untuk Admin:

- Admin dapat melihat semua riwayat peminjaman
- Admin dapat memaksa pengembalian buku
- Admin dapat memperpanjang tanggal jatuh tempo
- Admin dapat memfilter peminjaman berdasarkan status
- Sistem otomatis mengupdate status menjadi "overdue" jika melewati jatuh tempo

## Security Notes

⚠️ **Catatan Keamanan**:

- Sistem ini menggunakan MD5 untuk hashing password yang kurang aman untuk production
- Untuk production, disarankan menggunakan `password_hash()` dan `password_verify()` PHP
- Tambahkan validasi input yang lebih ketat
- Implementasikan CSRF protection

## Troubleshooting

### Error Koneksi Database

1. Pastikan MySQL berjalan di XAMPP
2. Periksa nama database, username, dan password di `config.php`
3. Pastikan database `perpustakaan` sudah dibuat

### Halaman Tidak Ditemukan

1. Pastikan Apache berjalan di XAMPP
2. Periksa path folder di `htdocs`
3. Akses melalui `localhost/perpustakaan`

### Error Permission

1. Pastikan folder memiliki permission yang benar
2. Di Windows, jalankan XAMPP sebagai Administrator

## Pengembangan Lebih Lanjut

Beberapa fitur yang bisa ditambahkan:

- Sistem peminjaman dan pengembalian buku
- Upload gambar cover buku
- Sistem notifikasi
- Report dan statistik yang lebih detail
- API untuk mobile app
- Sistem barcode untuk buku

## Lisensi

Project ini dibuat untuk tujuan pembelajaran dan dapat digunakan secara bebas.
