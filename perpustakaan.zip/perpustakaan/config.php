<?php
// Konfigurasi Database
$servername = "localhost";
$username = "root";
$password = "";
$database = "perpustakaan";

try {
    // Membuat koneksi ke database
    $conn = new mysqli($servername, $username, $password, $database);

    // Cek koneksi
    if ($conn->connect_error) {
        die("Koneksi gagal: " . $conn->connect_error);
    }

    // Set charset ke utf8
    $conn->set_charset("utf8");
} catch (Exception $e) {
    die("Error: " . $e->getMessage());
}

// Fungsi untuk membersihkan input
function clean_input($data)
{
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

// Fungsi untuk hash password
function hash_password($password)
{
    return md5($password);
}

// Fungsi untuk mengecek login
function check_login()
{
    if (!isset($_SESSION['user_id'])) {
        header("Location: login.php");
        exit();
    }
}

// Fungsi untuk mengecek apakah user adalah admin
function check_admin()
{
    if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
        header("Location: login.php");
        exit();
    }
}

// Fungsi untuk meminjam buku
function borrow_book($conn, $user_id, $book_id, $days = 7)
{
    // Cek apakah buku tersedia
    $check_stock = "SELECT stock FROM books WHERE id = ?";
    $stmt = $conn->prepare($check_stock);
    $stmt->bind_param("i", $book_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $book = $result->fetch_assoc();

    if (!$book || $book['stock'] <= 0) {
        return ['success' => false, 'message' => 'Buku tidak tersedia'];
    }

    // Cek apakah user sudah meminjam buku yang sama dan belum dikembalikan
    $check_existing = "SELECT id FROM borrowings WHERE user_id = ? AND book_id = ? AND status IN ('borrowed', 'overdue')";
    $stmt = $conn->prepare($check_existing);
    $stmt->bind_param("ii", $user_id, $book_id);
    $stmt->execute();
    $existing = $stmt->get_result();

    if ($existing->num_rows > 0) {
        return ['success' => false, 'message' => 'Anda sudah meminjam buku ini dan belum mengembalikannya'];
    }

    // Cek batasan maksimal peminjaman per user (maksimal 3 buku)
    $check_limit = "SELECT COUNT(*) as total FROM borrowings WHERE user_id = ? AND status IN ('borrowed', 'overdue')";
    $stmt = $conn->prepare($check_limit);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $limit_result = $stmt->get_result();
    $limit_data = $limit_result->fetch_assoc();

    if ($limit_data['total'] >= 3) {
        return ['success' => false, 'message' => 'Anda sudah meminjam maksimal 3 buku. Kembalikan buku terlebih dahulu.'];
    }

    // Cek apakah user memiliki buku yang terlambat
    $check_overdue = "SELECT COUNT(*) as overdue FROM borrowings WHERE user_id = ? AND status = 'overdue'";
    $stmt = $conn->prepare($check_overdue);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $overdue_result = $stmt->get_result();
    $overdue_data = $overdue_result->fetch_assoc();

    if ($overdue_data['overdue'] > 0) {
        return ['success' => false, 'message' => 'Anda memiliki buku yang terlambat dikembalikan. Kembalikan terlebih dahulu.'];
    }

    // Mulai transaksi
    $conn->begin_transaction();

    try {
        // Insert ke tabel borrowings
        $borrow_date = date('Y-m-d');
        $due_date = date('Y-m-d', strtotime("+$days days"));

        $insert_borrow = "INSERT INTO borrowings (user_id, book_id, borrow_date, due_date) VALUES (?, ?, ?, ?)";
        $stmt = $conn->prepare($insert_borrow);
        $stmt->bind_param("iiss", $user_id, $book_id, $borrow_date, $due_date);
        $stmt->execute();

        // Update stok buku
        $update_stock = "UPDATE books SET stock = stock - 1 WHERE id = ?";
        $stmt = $conn->prepare($update_stock);
        $stmt->bind_param("i", $book_id);
        $stmt->execute();

        $conn->commit();
        return ['success' => true, 'message' => 'Buku berhasil dipinjam! Harap dikembalikan sebelum tanggal ' . date('d/m/Y', strtotime($due_date))];
    } catch (Exception $e) {
        $conn->rollback();
        return ['success' => false, 'message' => 'Gagal meminjam buku: ' . $e->getMessage()];
    }
}

// Fungsi untuk mengembalikan buku
function return_book($conn, $borrowing_id, $user_id = null)
{
    // Cek apakah peminjaman valid
    $check_borrow = "SELECT b.book_id FROM borrowings b WHERE b.id = ? AND b.status = 'borrowed'";
    if ($user_id) {
        $check_borrow .= " AND b.user_id = ?";
    }

    $stmt = $conn->prepare($check_borrow);
    if ($user_id) {
        $stmt->bind_param("ii", $borrowing_id, $user_id);
    } else {
        $stmt->bind_param("i", $borrowing_id);
    }
    $stmt->execute();
    $result = $stmt->get_result();
    $borrow = $result->fetch_assoc();

    if (!$borrow) {
        return ['success' => false, 'message' => 'Peminjaman tidak ditemukan'];
    }

    // Mulai transaksi
    $conn->begin_transaction();

    try {
        // Update status peminjaman
        $return_date = date('Y-m-d');
        $update_borrow = "UPDATE borrowings SET return_date = ?, status = 'returned' WHERE id = ?";
        $stmt = $conn->prepare($update_borrow);
        $stmt->bind_param("si", $return_date, $borrowing_id);
        $stmt->execute();

        // Update stok buku
        $update_stock = "UPDATE books SET stock = stock + 1 WHERE id = ?";
        $stmt = $conn->prepare($update_stock);
        $stmt->bind_param("i", $borrow['book_id']);
        $stmt->execute();

        $conn->commit();
        return ['success' => true, 'message' => 'Buku berhasil dikembalikan'];
    } catch (Exception $e) {
        $conn->rollback();
        return ['success' => false, 'message' => 'Gagal mengembalikan buku: ' . $e->getMessage()];
    }
}

// Fungsi untuk update status overdue
function update_overdue_books($conn)
{
    $today = date('Y-m-d');
    $update_overdue = "UPDATE borrowings SET status = 'overdue' WHERE due_date < ? AND status = 'borrowed'";
    $stmt = $conn->prepare($update_overdue);
    $stmt->bind_param("s", $today);
    $stmt->execute();
}

// Konfigurasi denda
define('FINE_PER_DAY', 2000); // Denda per hari dalam rupiah

// Fungsi untuk menghitung denda
function calculate_fine($due_date, $return_date = null)
{
    $today = date('Y-m-d');
    $return_date = $return_date ? $return_date : $today;

    // Jika belum terlambat
    if ($return_date <= $due_date) {
        return 0;
    }

    // Hitung hari terlambat
    $due_timestamp = strtotime($due_date);
    $return_timestamp = strtotime($return_date);
    $days_late = ceil(($return_timestamp - $due_timestamp) / (60 * 60 * 24));

    return $days_late * FINE_PER_DAY;
}

// Fungsi untuk mengembalikan buku dengan perhitungan denda
function return_book_with_fine($conn, $borrowing_id, $user_id = null)
{
    // Cek apakah peminjaman valid
    $check_borrow = "SELECT b.book_id, b.due_date, b.status FROM borrowings b WHERE b.id = ?";
    if ($user_id) {
        $check_borrow .= " AND b.user_id = ?";
    }

    $stmt = $conn->prepare($check_borrow);
    if ($user_id) {
        $stmt->bind_param("ii", $borrowing_id, $user_id);
    } else {
        $stmt->bind_param("i", $borrowing_id);
    }
    $stmt->execute();
    $result = $stmt->get_result();
    $borrow = $result->fetch_assoc();

    if (!$borrow) {
        return ['success' => false, 'message' => 'Peminjaman tidak ditemukan'];
    }

    if ($borrow['status'] == 'returned') {
        return ['success' => false, 'message' => 'Buku sudah dikembalikan sebelumnya'];
    }

    // Hitung denda
    $return_date = date('Y-m-d');
    $fine_amount = calculate_fine($borrow['due_date'], $return_date);

    // Mulai transaksi
    $conn->begin_transaction();

    try {
        // Update status peminjaman dengan denda
        $update_borrow = "UPDATE borrowings SET return_date = ?, status = 'returned', fine_amount = ? WHERE id = ?";
        $stmt = $conn->prepare($update_borrow);
        $stmt->bind_param("sii", $return_date, $fine_amount, $borrowing_id);
        $stmt->execute();

        // Update stok buku
        $update_stock = "UPDATE books SET stock = stock + 1 WHERE id = ?";
        $stmt = $conn->prepare($update_stock);
        $stmt->bind_param("i", $borrow['book_id']);
        $stmt->execute();

        $conn->commit();

        $message = 'Buku berhasil dikembalikan';
        if ($fine_amount > 0) {
            $message .= '. Denda keterlambatan: Rp ' . number_format($fine_amount, 0, ',', '.');
        }

        return ['success' => true, 'message' => $message, 'fine' => $fine_amount];
    } catch (Exception $e) {
        $conn->rollback();
        return ['success' => false, 'message' => 'Gagal mengembalikan buku: ' . $e->getMessage()];
    }
}

// Fungsi untuk mendapatkan total denda user
function get_user_total_fines($conn, $user_id)
{
    $query = "SELECT SUM(fine_amount) as total_fines FROM borrowings WHERE user_id = ? AND fine_amount > 0 AND fine_paid = 0";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $data = $result->fetch_assoc();

    return $data['total_fines'] ? (int)$data['total_fines'] : 0;
}

// Fungsi untuk membayar denda
function pay_fine($conn, $borrowing_id)
{
    $update_fine = "UPDATE borrowings SET fine_paid = 1, fine_paid_date = NOW() WHERE id = ? AND fine_amount > 0";
    $stmt = $conn->prepare($update_fine);
    $stmt->bind_param("i", $borrowing_id);

    if ($stmt->execute() && $stmt->affected_rows > 0) {
        return ['success' => true, 'message' => 'Denda berhasil dibayar'];
    } else {
        return ['success' => false, 'message' => 'Gagal membayar denda'];
    }
}
