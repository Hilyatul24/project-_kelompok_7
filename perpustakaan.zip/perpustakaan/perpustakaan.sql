-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 04, 2025 at 04:01 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `perpustakaan`
--

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE `books` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `author` varchar(255) NOT NULL,
  `isbn` varchar(50) DEFAULT NULL,
  `publisher` varchar(255) DEFAULT NULL,
  `year_published` year(4) DEFAULT NULL,
  `stock` int(11) DEFAULT 0,
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`id`, `title`, `author`, `isbn`, `publisher`, `year_published`, `stock`, `description`, `created_at`, `updated_at`) VALUES
(1, 'Laskar Pelangi', 'Andrea Hirata', '9789792241082', 'Bentang Pustaka', '2005', 10, '0', '2025-10-03 17:09:30', '2025-10-04 10:53:49'),
(2, 'Bumi Manusia', 'Pramoedya Ananta Toer', '9789799731234', 'Hasta Mitra', '1980', 5, 'Novel sejarah tentang kehidupan di masa kolonial', '2025-10-03 17:09:30', '2025-10-04 11:00:24'),
(3, 'Ayat-Ayat Cinta', 'Habiburrahman El Shirazy', '9789792245671', 'Republika', '2004', 10, '0', '2025-10-03 17:09:30', '2025-10-03 17:13:06'),
(4, 'Harry Potter and the Sorcerer&#039;s Stone', 'J.K. Rowling', '9780000001001', 'Bloomsbury', '1997', 10, '0', '2025-10-04 11:11:04', '2025-10-04 11:12:12'),
(5, 'The Lord of the Rings', 'J.R.R. Tolkien', '9780000001002', 'Allen & Unwin', '1954', 8, 'Epos fantasi tentang Cincin Utama.', '2025-10-04 11:11:04', '2025-10-04 11:11:04'),
(6, 'The Hobbit', 'J.R.R. Tolkien', '9780000001003', 'Allen & Unwin', '1937', 8, 'Perjalanan Bilbo Baggins menuju Lonely Mountain.', '2025-10-04 11:11:04', '2025-10-04 11:11:04'),
(7, 'Pride and Prejudice', 'Jane Austen', '9780000001004', 'Penguin Classics', '0000', 10, 'Romansa klasik Elizabeth Bennet & Mr. Darcy.', '2025-10-04 11:11:04', '2025-10-04 11:11:04'),
(8, 'To Kill a Mockingbird', 'Harper Lee', '9780000001005', 'Harper Perennial', '1960', 9, 'Isu ras dan keadilan di Maycomb.', '2025-10-04 11:11:04', '2025-10-04 11:11:04'),
(9, '1984', 'George Orwell', '9780000001006', 'Secker & Warburg', '1949', 11, 'Dunia distopia Big Brother.', '2025-10-04 11:11:04', '2025-10-04 11:11:04'),
(10, 'The Great Gatsby', 'F. Scott Fitzgerald', '9780000001007', 'Scribner', '1925', 10, 'Misteri dan glamor era Jazz.', '2025-10-04 11:11:04', '2025-10-04 11:11:04'),
(11, 'The Catcher in the Rye', 'J.D. Salinger', '9780000001008', 'Little, Brown and Company', '1951', 7, 'Holden Caulfield mencari makna.', '2025-10-04 11:11:04', '2025-10-04 11:11:04'),
(12, 'The Da Vinci Code', 'Dan Brown', '9780000001009', 'Doubleday', '2003', 12, 'Thriller konspirasi seni & simbol.', '2025-10-04 11:11:04', '2025-10-04 11:11:04'),
(13, 'The Alchemist', 'Paulo Coelho', '9780000001010', 'HarperOne', '1988', 15, 'Perjalanan Santiago mengejar mimpi.', '2025-10-04 11:11:04', '2025-10-04 11:11:04'),
(14, 'The Little Prince', 'Antoine de Saint-Exupéry', '9780000001011', 'Reynal & Hitchcock', '1943', 10, 'Dongeng filsafat tentang persahabatan.', '2025-10-04 11:11:04', '2025-10-04 11:11:04'),
(15, 'The Lion, the Witch and the Wardrobe', 'C.S. Lewis', '9780000001012', 'Geoffrey Bles', '1950', 9, 'Petualangan anak-anak Pevensie di Narnia.', '2025-10-04 11:11:04', '2025-10-04 11:11:04'),
(16, 'Moby-Dick', 'Herman Melville', '9780000001013', 'Harper & Brothers', '0000', 6, 'Obsesi Ahab memburu ikan paus putih.', '2025-10-04 11:11:04', '2025-10-04 11:11:04'),
(17, 'War and Peace', 'Leo Tolstoy', '9780000001014', 'The Russian Messenger', '0000', 5, 'Epos Rusia masa perang Napoleon.', '2025-10-04 11:11:04', '2025-10-04 11:11:04'),
(18, 'Crime and Punishment', 'Fyodor Dostoevsky', '9780000001015', 'The Russian Messenger', '0000', 6, 'Pergulatan moral Raskolnikov.', '2025-10-04 11:11:04', '2025-10-04 11:11:04'),
(19, 'One Hundred Years of Solitude', 'Gabriel García Márquez', '9780000001016', 'Harper & Row', '1967', 8, 'Saga keluarga Buendía di Macondo.', '2025-10-04 11:11:04', '2025-10-04 11:11:04'),
(20, 'The Kite Runner', 'Khaled Hosseini', '9780000001017', 'Riverhead Books', '2003', 10, 'Persahabatan dan penebusan di Kabul.', '2025-10-04 11:11:04', '2025-10-04 11:11:04'),
(21, 'The Girl with the Dragon Tattoo', 'Stieg Larsson', '9780000001018', 'Norstedts', '2005', 10, 'Misteri investigasi jurnalis & hacker.', '2025-10-04 11:11:04', '2025-10-04 11:11:04'),
(22, 'The Hunger Games', 'Suzanne Collins', '9780000001019', 'Scholastic Press', '2008', 12, 'Pertarungan hidup Katniss Everdeen.', '2025-10-04 11:11:04', '2025-10-04 11:11:04'),
(23, 'Twilight', 'Stephenie Meyer', '9780000001020', 'Little, Brown and Company', '2005', 10, 'Romansa vampir remaja.', '2025-10-04 11:11:04', '2025-10-04 11:11:04'),
(24, 'The Fault in Our Stars', 'John Green', '9780000001021', 'Dutton Books', '2012', 12, 'Kisah cinta Hazel & Gus.', '2025-10-04 11:11:04', '2025-10-04 11:11:04'),
(25, 'The Handmaid\'s Tale', 'Margaret Atwood', '9780000001022', 'McClelland & Stewart', '1985', 7, 'Republik Gilead dan peran perempuan.', '2025-10-04 11:11:04', '2025-10-04 11:11:04'),
(26, 'The Book Thief', 'Markus Zusak', '9780000001023', 'Knopf', '2005', 9, 'Gadis pencuri buku di Nazi Jerman.', '2025-10-04 11:11:04', '2025-10-04 11:11:04'),
(27, 'The Shining', 'Stephen King', '9780000001024', 'Doubleday', '1977', 8, 'Teror di Hotel Overlook.', '2025-10-04 11:11:04', '2025-10-04 11:11:04'),
(28, 'A Game of Thrones', 'George R.R. Martin', '9780000001025', 'Bantam Spectra', '1996', 12, 'Intrik perebutan takhta Westeros.', '2025-10-04 11:11:04', '2025-10-04 11:11:04'),
(29, 'The Name of the Wind', 'Patrick Rothfuss', '9780000001026', 'DAW Books', '2007', 10, 'Kisah Kvothe sang legenda.', '2025-10-04 11:11:04', '2025-10-04 11:11:04'),
(30, 'The Martian', 'Andy Weir', '9780000001027', 'Crown', '2011', 12, 'Astronaut terdampar di Mars.', '2025-10-04 11:11:04', '2025-10-04 11:11:04'),
(31, 'Ready Player One', 'Ernest Cline', '9780000001028', 'Crown', '2011', 10, 'Perburuan easter egg di OASIS.', '2025-10-04 11:11:04', '2025-10-04 11:11:04'),
(32, 'The Road', 'Cormac McCarthy', '9780000001029', 'Knopf', '2006', 7, 'Perjalanan ayah-anak pasca-apokaliptik.', '2025-10-04 11:11:04', '2025-10-04 11:11:04'),
(33, 'Life of Pi', 'Yann Martel', '9780000001030', 'Knopf Canada', '2001', 10, 'Bocah India terombang-ambing dengan harimau.', '2025-10-04 11:11:04', '2025-10-04 11:11:04'),
(34, 'The Girl on the Train', 'Paula Hawkins', '9780000001031', 'Riverhead Books', '2015', 11, 'Thriller psikologis saksi kereta.', '2025-10-04 11:11:04', '2025-10-04 11:11:04'),
(35, 'The Help', 'Kathryn Stockett', '9780000001032', 'Amy Einhorn Books', '2009', 9, 'Kisah pembantu rumah tangga di Mississippi.', '2025-10-04 11:11:04', '2025-10-04 11:11:04'),
(36, 'The Giver', 'Lois Lowry', '9780000001033', 'Houghton Mifflin', '1993', 8, 'Masyarakat tanpa rasa sakit & warna.', '2025-10-04 11:11:04', '2025-10-04 11:11:04'),
(37, 'The Outsiders', 'S.E. Hinton', '9780000001034', 'Viking Press', '1967', 7, 'Geng remaja Greasers vs Socs.', '2025-10-04 11:11:04', '2025-10-04 11:11:04'),
(38, 'The Picture of Dorian Gray', 'Oscar Wilde', '9780000001035', 'Lippincott\'s Monthly Magazine', '0000', 6, 'Potret yang menua menggantikan Dorian.', '2025-10-04 11:11:04', '2025-10-04 11:11:04'),
(39, 'The Color Purple', 'Alice Walker', '9780000001036', 'Harcourt', '1982', 7, 'Perjuangan Celie di Amerika Selatan.', '2025-10-04 11:11:04', '2025-10-04 11:11:04'),
(40, 'Brave New World', 'Aldous Huxley', '9780000001037', 'Chatto & Windus', '1932', 9, 'Dunia masa depan yang terkontrol.', '2025-10-04 11:11:04', '2025-10-04 11:11:04'),
(41, 'The Wind-Up Bird Chronicle', 'Haruki Murakami', '9780000001038', 'Shinchosha', '1994', 6, 'Pencarian metafisik Toru Okada.', '2025-10-04 11:11:04', '2025-10-04 11:11:04'),
(42, 'Norwegian Wood', 'Haruki Murakami', '9780000001039', 'Kodansha', '1987', 8, 'Cinta & kehilangan di Tokyo 60-an.', '2025-10-04 11:11:04', '2025-10-04 11:11:04'),
(43, 'Kafka on the Shore', 'Haruki Murakami', '9780000001040', 'Shinchosha', '2002', 7, 'Kisah paralel Kafka & Nakata.', '2025-10-04 11:11:04', '2025-10-04 11:11:04'),
(44, 'The Shadow of the Wind', 'Carlos Ruiz Zafón', '9780000001041', 'Planeta', '2001', 8, 'Misteri di Cemetery of Forgotten Books.', '2025-10-04 11:11:04', '2025-10-04 11:11:04'),
(45, 'The Curious Incident of the Dog in the Night-Time', 'Mark Haddon', '9780000001042', 'Jonathan Cape', '2003', 8, 'Remaja spektrum autisme pecahkan misteri.', '2025-10-04 11:11:04', '2025-10-04 11:11:04'),
(46, 'The Girl Who Played with Fire', 'Stieg Larsson', '9780000001043', 'Norstedts', '2006', 9, 'Sekuel Lisbeth Salander.', '2025-10-04 11:11:04', '2025-10-04 11:11:04'),
(47, 'Angels & Demons', 'Dan Brown', '9780000001044', 'Pocket Books', '2000', 11, 'Rahasia Illuminati di Vatikan.', '2025-10-04 11:11:04', '2025-10-04 11:11:04'),
(48, 'The Silence of the Lambs', 'Thomas Harris', '9780000001045', 'St. Martin\'s Press', '1988', 7, 'Clarice Starling & Hannibal Lecter.', '2025-10-04 11:11:04', '2025-10-04 11:11:04'),
(49, 'Gone Girl', 'Gillian Flynn', '9780000001046', 'Crown', '2012', 10, 'Pernikahan beracun & hilangnya Amy.', '2025-10-04 11:11:04', '2025-10-04 11:11:04'),
(50, 'The Night Circus', 'Erin Morgenstern', '9780000001047', 'Doubleday', '2011', 9, 'Sirkus magis muncul tanpa peringatan.', '2025-10-04 11:11:04', '2025-10-04 11:11:04'),
(51, 'The Goldfinch', 'Donna Tartt', '9780000001048', 'Little, Brown and Company', '2013', 7, 'Kehilangan, seni, dan identitas.', '2025-10-04 11:11:04', '2025-10-04 11:11:04'),
(52, 'The Subtle Art of Not Giving a F*ck', 'Mark Manson', '9780000001049', 'HarperOne', '2016', 12, 'Self-help anti-mainstream.', '2025-10-04 11:11:04', '2025-10-04 11:11:04'),
(53, 'Sapiens: A Brief History of Humankind', 'Yuval Noah Harari', '9780000001050', 'Harvill Secker', '2011', 15, 'Sejarah singkat spesies manusia.', '2025-10-04 11:11:04', '2025-10-04 11:11:04'),
(54, 'yang katanya cemara', 'vania', '1244444141', 'gramedia', '2020', 2, 'seorang buku yang menceritakan tentang keluarga hangat yang saling menjaga satu sama lain', '2025-10-04 11:14:51', '2025-10-04 11:14:51');

-- --------------------------------------------------------

--
-- Table structure for table `borrowings`
--

CREATE TABLE `borrowings` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `book_id` int(11) NOT NULL,
  `borrow_date` date NOT NULL,
  `due_date` date NOT NULL,
  `return_date` date DEFAULT NULL,
  `status` enum('borrowed','returned','overdue') NOT NULL DEFAULT 'borrowed',
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `fine_amount` int(11) DEFAULT 0 COMMENT 'Jumlah denda dalam rupiah',
  `fine_paid` tinyint(1) DEFAULT 0 COMMENT 'Status pembayaran denda (0=belum, 1=sudah)',
  `fine_paid_date` datetime DEFAULT NULL COMMENT 'Tanggal pembayaran denda'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `borrowings`
--

INSERT INTO `borrowings` (`id`, `user_id`, `book_id`, `borrow_date`, `due_date`, `return_date`, `status`, `notes`, `created_at`, `updated_at`, `fine_amount`, `fine_paid`, `fine_paid_date`) VALUES
(2, 2, 3, '2025-10-03', '2025-10-10', '2025-10-03', 'returned', NULL, '2025-10-03 17:11:30', '2025-10-03 17:13:06', 0, 0, NULL),
(3, 2, 2, '2025-10-03', '2025-10-11', '2025-10-03', 'returned', NULL, '2025-10-03 18:42:43', '2025-10-03 18:56:50', 0, 0, NULL),
(4, 4, 2, '2025-10-04', '2025-10-11', '2025-10-04', 'returned', NULL, '2025-10-04 09:50:15', '2025-10-04 10:56:36', 0, 0, NULL),
(5, 2, 2, '2025-10-04', '2025-10-13', '2025-10-04', 'returned', NULL, '2025-10-04 09:50:38', '2025-10-04 10:53:39', 0, 0, NULL),
(6, 2, 1, '2025-10-04', '2025-10-11', '2025-10-04', 'returned', NULL, '2025-10-04 10:45:18', '2025-10-04 10:53:49', 0, 0, NULL),
(7, 4, 2, '2025-10-04', '2025-10-11', '2025-10-04', 'returned', NULL, '2025-10-04 11:00:16', '2025-10-04 11:00:24', 0, 0, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('user','admin') NOT NULL DEFAULT 'user',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `role`, `created_at`) VALUES
(1, 'admin', 'admin@perpustakaan.com', '0192023a7bbd73250516f069df18b500', 'admin', '2025-10-03 17:09:30'),
(2, 'bayu', 'bayu@gmail.com', '6db181fea88ef1963cb7c71145db56b4', 'user', '2025-10-03 17:11:13'),
(3, 'bayuu', 'bayuu@gmail.com', '6db181fea88ef1963cb7c71145db56b4', 'user', '2025-10-03 18:23:58'),
(4, 'tes', 'tes@gmail.com', '6e7906b7fb3f8e1c6366c0910050e595', 'user', '2025-10-04 09:49:36');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `isbn` (`isbn`);

--
-- Indexes for table `borrowings`
--
ALTER TABLE `borrowings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `book_id` (`book_id`),
  ADD KEY `idx_user_fine` (`user_id`,`fine_paid`),
  ADD KEY `idx_status_due` (`status`,`due_date`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `books`
--
ALTER TABLE `books`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55;

--
-- AUTO_INCREMENT for table `borrowings`
--
ALTER TABLE `borrowings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `borrowings`
--
ALTER TABLE `borrowings`
  ADD CONSTRAINT `borrowings_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `borrowings_ibfk_2` FOREIGN KEY (`book_id`) REFERENCES `books` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
