<?php
session_start();
require_once '../config.php';

// Cek apakah user sudah login
check_login();

// Update status overdue
update_overdue_books($conn);

$message = '';
$message_type = '';

// Handle peminjaman buku
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['borrow_book'])) {
    $book_id = (int)$_POST['book_id'];
    $result = borrow_book($conn, $_SESSION['user_id'], $book_id);

    $message = $result['message'];
    $message_type = $result['success'] ? 'success' : 'error';
}

// Ambil daftar buku
$search = isset($_GET['search']) ? clean_input($_GET['search']) : '';
$books_query = "SELECT * FROM books";
if (!empty($search)) {
    $books_query .= " WHERE title LIKE '%" . $search . "%' OR author LIKE '%" . $search . "%'";
}
$books_query .= " ORDER BY title ASC";
$books_result = $conn->query($books_query);

// Cek denda user
$user_fines = get_user_total_fines($conn, $_SESSION['user_id']);
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard User - Perpustakaan</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link rel="stylesheet" href="../style-tailwind.css">
    <style>
    .line-clamp-3 {
        display: -webkit-box;
        -webkit-line-clamp: 3;
        line-clamp: 3;
        -webkit-box-orient: vertical;
        overflow: hidden;
    }

    .book-card {
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    }

    .book-card:hover {
        transform: translateY(-4px);
        box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
    }

    @keyframes fadeIn {
        from {
            opacity: 0;
            transform: translateY(20px);
        }

        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    .animate-fade-in {
        animation: fadeIn 0.5s ease-out;
    }

    .gradient-border {
        background: linear-gradient(45deg, #3b82f6, #8b5cf6, #06b6d4);
        background-size: 400% 400%;
        animation: gradient 3s ease infinite;
    }

    @keyframes gradient {
        0% {
            background-position: 0% 50%;
        }

        50% {
            background-position: 100% 50%;
        }

        100% {
            background-position: 0% 50%;
        }
    }
    </style>
</head>

<body class="bg-gray-100">
    <div class="flex h-screen">
        <!-- Sidebar -->
        <div class="sidebar-gradient w-64 text-white flex flex-col">
            <div class="p-6 border-b border-white border-opacity-20">
                <h3 class="text-xl font-bold">📚 Perpustakaan</h3>
            </div>
            <nav class="flex-1 px-4 py-6 space-y-2">
                <a href="dashboard.php"
                    class="flex items-center px-4 py-3 text-white bg-white bg-opacity-20 rounded-lg font-medium">
                    📖 Dashboard
                </a>
                <a href="borrowings.php"
                    class="flex items-center px-4 py-3 text-white hover:bg-white hover:bg-opacity-10 rounded-lg transition-colors">
                    📋 Peminjaman Saya
                </a>
                <a href="profile.php"
                    class="flex items-center px-4 py-3 text-white hover:bg-white hover:bg-opacity-10 rounded-lg transition-colors">
                    👤 Profile Saya
                </a>
                <a href="../logout.php"
                    class="flex items-center px-4 py-3 text-white hover:bg-white hover:bg-opacity-10 rounded-lg transition-colors">
                    🚪 Logout
                </a>
            </nav>
        </div>

        <!-- Main Content -->
        <div class="flex-1 flex flex-col overflow-hidden">
            <!-- Header -->
            <div class="bg-white shadow-sm border-b border-gray-200 px-6 py-4">
                <div class="flex justify-between items-center">
                    <h1 class="text-2xl font-bold text-gray-900">Dashboard User</h1>
                    <div class="flex items-center space-x-3">
                        <div
                            class="w-8 h-8 bg-gradient-to-r from-green-500 to-blue-600 rounded-full flex items-center justify-center text-white font-bold text-sm">
                            <?php echo strtoupper(substr($_SESSION['username'], 0, 1)); ?>
                        </div>
                        <div class="text-sm">
                            <div class="font-medium text-gray-900"><?php echo $_SESSION['username']; ?></div>
                            <div class="text-gray-500">User</div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Content -->
            <div class="flex-1 overflow-auto p-6">
                <!-- Welcome Section -->
                <div class="bg-white rounded-lg shadow-sm p-6 mb-6">
                    <p class="text-gray-600">Selamat datang, <span
                            class="font-medium text-gray-900"><?php echo $_SESSION['username']; ?></span>!</p>
                </div>

                <?php if (!empty($message)): ?>
                <script>
                document.addEventListener('DOMContentLoaded', function() {
                    Swal.fire({
                        icon: '<?php echo $message_type == "success" ? "success" : "error"; ?>',
                        title: '<?php echo $message_type == "success" ? "Berhasil!" : "Error!"; ?>',
                        text: '<?php echo addslashes($message); ?>',
                        confirmButtonColor: '#3085d6'
                    });
                });
                </script>
                <?php endif; ?>

                <?php if ($user_fines > 0): ?>
                <!-- Fine Alert -->
                <div class="mb-6 p-4 bg-red-100 border border-red-400 text-red-700 rounded-lg">
                    <div class="flex items-center">
                        <svg class="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 20 20">
                            <path fill-rule="evenodd"
                                d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z"
                                clip-rule="evenodd"></path>
                        </svg>
                        <strong>Anda memiliki denda yang belum dibayar: Rp
                            <?php echo number_format($user_fines, 0, ',', '.'); ?></strong>
                    </div>
                    <p class="mt-2 text-sm">Silakan bayar denda di menu "Peminjaman Saya" atau hubungi petugas
                        perpustakaan.</p>
                </div>
                <?php endif; ?>

                <!-- Search Section -->
                <div class="bg-white rounded-lg shadow-sm p-6 mb-6">
                    <h2 class="text-lg font-medium text-gray-900 mb-4">Cari Buku</h2>
                    <form method="GET" action="" class="flex flex-col sm:flex-row gap-4">
                        <input type="text" name="search" placeholder="Cari berdasarkan judul atau penulis..."
                            value="<?php echo htmlspecialchars($search); ?>"
                            class="flex-1 px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500">
                        <button type="submit"
                            class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-md font-medium transition-colors">
                            Cari
                        </button>
                        <?php if (!empty($search)): ?>
                        <a href="dashboard.php"
                            class="bg-gray-600 hover:bg-gray-700 text-white px-4 py-2 rounded-md font-medium transition-colors">
                            Reset
                        </a>
                        <?php endif; ?>
                    </form>
                </div>

                <!-- Books Section -->
                <div class="bg-white rounded-lg shadow-sm p-6 mb-6">
                    <h2 class="text-lg font-medium text-gray-900 mb-4">
                        Daftar Buku
                        <?php if (!empty($search)): ?>
                        <span class="text-sm text-gray-500 font-normal">(Hasil pencarian:
                            "<?php echo htmlspecialchars($search); ?>")</span>
                        <?php endif; ?>
                    </h2>

                    <?php if ($books_result->num_rows > 0): ?>
                    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        <?php while ($book = $books_result->fetch_assoc()): ?>
                        <div class="book-card border border-gray-200 rounded-lg p-6 bg-white animate-fade-in">
                            <div class="mb-4">
                                <h3 class="text-lg font-semibold text-gray-900 mb-1 hover:text-blue-600 transition-colors cursor-pointer"
                                    onclick="showBookDetail({
                                                id: <?php echo $book['id']; ?>,
                                                title: '<?php echo addslashes(htmlspecialchars($book['title'])); ?>',
                                                author: '<?php echo addslashes(htmlspecialchars($book['author'])); ?>',
                                                publisher: '<?php echo addslashes(htmlspecialchars($book['publisher'] ?? '')); ?>',
                                                year_published: '<?php echo $book['year_published'] ?? ''; ?>',
                                                isbn: '<?php echo addslashes(htmlspecialchars($book['isbn'] ?? '')); ?>',
                                                description: '<?php echo addslashes(htmlspecialchars($book['description'] ?? '')); ?>',
                                                stock: <?php echo $book['stock']; ?>
                                            })">
                                    <?php echo htmlspecialchars($book['title']); ?>
                                </h3>
                                <p class="text-gray-600 text-sm">oleh <?php echo htmlspecialchars($book['author']); ?>
                                </p>
                            </div>

                            <div class="space-y-2 mb-4 text-sm">
                                <?php if (!empty($book['publisher'])): ?>
                                <p><span class="font-medium text-gray-700">Penerbit:</span> <span
                                        class="text-gray-600"><?php echo htmlspecialchars($book['publisher']); ?></span>
                                </p>
                                <?php endif; ?>

                                <?php if (!empty($book['year_published'])): ?>
                                <p><span class="font-medium text-gray-700">Tahun:</span> <span
                                        class="text-gray-600"><?php echo $book['year_published']; ?></span></p>
                                <?php endif; ?>

                                <?php if (!empty($book['isbn'])): ?>
                                <p><span class="font-medium text-gray-700">ISBN:</span> <span
                                        class="text-gray-600"><?php echo htmlspecialchars($book['isbn']); ?></span></p>
                                <?php endif; ?>

                                <p><span class="font-medium text-gray-700">Stok:</span>
                                    <span
                                        class="<?php echo $book['stock'] > 0 ? 'text-green-600' : 'text-red-600'; ?> font-medium">
                                        <?php echo $book['stock']; ?>
                                        <?php echo $book['stock'] > 0 ? ' tersedia' : ' (kosong)'; ?>
                                    </span>
                                </p>
                            </div>

                            <?php if (!empty($book['description'])): ?>
                            <div class="mb-4">
                                <p class="text-gray-600 text-sm line-clamp-3">
                                    <?php echo strlen($book['description']) > 120 ? substr(htmlspecialchars($book['description']), 0, 120) . '...' : htmlspecialchars($book['description']); ?>
                                </p>
                            </div>
                            <?php endif; ?>

                            <div class="flex items-center justify-between">
                                <span
                                    class="inline-flex px-2 py-1 text-xs font-semibold rounded-full <?php echo $book['stock'] > 0 ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'; ?>">
                                    <?php echo $book['stock'] > 0 ? 'Tersedia' : 'Tidak Tersedia'; ?>
                                </span>

                                <div class="flex gap-2">
                                    <!-- Detail Button -->
                                    <button type="button" onclick="showBookDetail({
                                                    id: <?php echo $book['id']; ?>,
                                                    title: '<?php echo addslashes(htmlspecialchars($book['title'])); ?>',
                                                    author: '<?php echo addslashes(htmlspecialchars($book['author'])); ?>',
                                                    publisher: '<?php echo addslashes(htmlspecialchars($book['publisher'] ?? '')); ?>',
                                                    year_published: '<?php echo $book['year_published'] ?? ''; ?>',
                                                    isbn: '<?php echo addslashes(htmlspecialchars($book['isbn'] ?? '')); ?>',
                                                    description: '<?php echo addslashes(htmlspecialchars($book['description'] ?? '')); ?>',
                                                    stock: <?php echo $book['stock']; ?>
                                                })"
                                        class="bg-gray-600 hover:bg-gray-700 text-white px-3 py-1 rounded text-sm font-medium transition-colors">
                                        📖 Detail
                                    </button>

                                    <!-- Borrow Button -->
                                    <?php if ($book['stock'] > 0): ?>
                                    <button type="button"
                                        onclick="confirmBorrowBook(<?php echo $book['id']; ?>, '<?php echo addslashes(htmlspecialchars($book['title'])); ?>')"
                                        class="bg-blue-600 hover:bg-blue-700 text-white px-3 py-1 rounded text-sm font-medium transition-colors">
                                        📚 Pinjam
                                    </button>
                                    <?php else: ?>
                                    <button type="button" disabled
                                        class="bg-gray-400 cursor-not-allowed text-white px-3 py-1 rounded text-sm font-medium">
                                        ❌ Kosong
                                    </button>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <?php endwhile; ?>
                    </div>
                    <?php else: ?>
                    <div class="text-center py-8">
                        <?php if (!empty($search)): ?>
                        <p class="text-gray-500 mb-4">Tidak ada buku yang ditemukan dengan kata kunci
                            "<?php echo htmlspecialchars($search); ?>".</p>
                        <a href="dashboard.php"
                            class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-md font-medium transition-colors">
                            Lihat Semua Buku
                        </a>
                        <?php else: ?>
                        <p class="text-gray-500">Belum ada buku tersedia di perpustakaan.</p>
                        <?php endif; ?>
                    </div>
                    <?php endif; ?>
                </div>

            </div>
        </div>
    </div>

    <script>
    // Function to show book detail dialog
    function showBookDetail(bookData) {
        const bookInfo = `
                <div class="text-left space-y-4">
                    <div class="border-b pb-4 mb-4">
                        <h3 class="text-xl font-bold text-gray-800 mb-2">${bookData.title}</h3>
                        <p class="text-gray-600 font-medium">oleh ${bookData.author}</p>
                    </div>
                    
                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm">
                        ${bookData.publisher ? `<div class="bg-gray-50 p-3 rounded-lg"><span class="font-semibold text-gray-700 block mb-1">📚 Penerbit:</span><span class="text-gray-600">${bookData.publisher}</span></div>` : ''}
                        ${bookData.year_published ? `<div class="bg-gray-50 p-3 rounded-lg"><span class="font-semibold text-gray-700 block mb-1">📅 Tahun Terbit:</span><span class="text-gray-600">${bookData.year_published}</span></div>` : ''}
                        ${bookData.isbn ? `<div class="bg-gray-50 p-3 rounded-lg"><span class="font-semibold text-gray-700 block mb-1">🔢 ISBN:</span><span class="text-gray-600">${bookData.isbn}</span></div>` : ''}
                        <div class="bg-gray-50 p-3 rounded-lg"><span class="font-semibold text-gray-700 block mb-1">📦 Ketersediaan:</span><span class="font-medium ${bookData.stock > 0 ? 'text-green-600' : 'text-red-600'}">${bookData.stock} ${bookData.stock > 0 ? 'tersedia' : '(kosong)'}</span></div>
                    </div>
                    
                    ${bookData.description ? `
                    <div class="mt-4 pt-4 border-t bg-blue-50 p-4 rounded-lg">
                        <span class="font-semibold text-gray-700 block mb-2">📝 Deskripsi:</span>
                        <p class="text-gray-600 leading-relaxed">${bookData.description}</p>
                    </div>
                    ` : ''}
                </div>
            `;

        Swal.fire({
            title: '<div class="flex items-center gap-2"><span class="text-2xl">📖</span><span>Detail Buku</span></div>',
            html: bookInfo,
            width: 700,
            showCancelButton: bookData.stock > 0,
            confirmButtonText: bookData.stock > 0 ? '<i class="mr-2">📚</i> Pinjam Buku Sekarang' :
                '<i class="mr-2">✅</i> Tutup',
            cancelButtonText: '<i class="mr-2">❌</i> Tutup',
            confirmButtonColor: bookData.stock > 0 ? '#2563eb' : '#6b7280',
            cancelButtonColor: '#6b7280',
            showCloseButton: true,
            customClass: {
                popup: 'rounded-2xl shadow-2xl',
                title: 'text-lg font-bold text-gray-800',
                confirmButton: 'font-semibold px-6 py-3 rounded-lg',
                cancelButton: 'font-semibold px-6 py-3 rounded-lg'
            },
            backdrop: `rgba(0,0,0,0.4)`,
            allowOutsideClick: true,
            allowEscapeKey: true
        }).then((result) => {
            if (result.isConfirmed && bookData.stock > 0) {
                // Show borrow confirmation
                confirmBorrowBook(bookData.id, bookData.title);
            }
        });
    }

    // Function to confirm book borrowing
    function confirmBorrowBook(bookId, bookTitle) {
        Swal.fire({
            title: '<div class="flex items-center gap-2"><span class="text-2xl">📚</span><span>Konfirmasi Peminjaman</span></div>',
            html: `
                    <div class="text-center p-4">
                        <div class="mb-4 p-4 bg-blue-50 rounded-xl">
                            <p class="text-gray-700 mb-2">Apakah Anda yakin ingin meminjam buku:</p>
                            <p class="font-bold text-blue-600 text-lg">"${bookTitle}"</p>
                        </div>
                        <div class="text-sm text-gray-600 bg-yellow-50 p-3 rounded-lg">
                            <p class="font-medium text-yellow-700 mb-1">⚠️ Ketentuan Peminjaman:</p>
                            <ul class="text-left list-disc list-inside space-y-1">
                                <li>Batas waktu peminjaman: 7 hari</li>
                                <li>Denda keterlambatan: Rp 2.000/hari</li>
                                <li>Jaga kondisi buku dengan baik</li>
                            </ul>
                        </div>
                    </div>
                `,
            icon: 'question',
            showCancelButton: true,
            confirmButtonText: '<i class="mr-2">✅</i> Ya, Saya Setuju & Pinjam!',
            cancelButtonText: '<i class="mr-2">❌</i> Batal',
            confirmButtonColor: '#10b981',
            cancelButtonColor: '#ef4444',
            reverseButtons: true,
            customClass: {
                popup: 'rounded-2xl shadow-2xl',
                confirmButton: 'font-semibold px-6 py-3 rounded-lg',
                cancelButton: 'font-semibold px-6 py-3 rounded-lg'
            },
            backdrop: `rgba(0,0,0,0.4)`
        }).then((result) => {
            if (result.isConfirmed) {
                // Show loading with animation
                Swal.fire({
                    title: '<div class="flex items-center gap-2"><span class="text-2xl">⏳</span><span>Memproses Peminjaman...</span></div>',
                    html: `
                            <div class="text-center p-4">
                                <div class="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mb-4"></div>
                                <p class="text-gray-600">Sedang memproses peminjaman buku</p>
                                <p class="text-sm text-gray-500 mt-2">"${bookTitle}"</p>
                            </div>
                        `,
                    allowOutsideClick: false,
                    allowEscapeKey: false,
                    showConfirmButton: false,
                    customClass: {
                        popup: 'rounded-2xl shadow-2xl'
                    },
                    backdrop: `rgba(0,0,0,0.6)`
                });

                // Submit the form after a small delay for better UX
                setTimeout(() => {
                    const form = document.createElement('form');
                    form.method = 'POST';
                    form.style.display = 'none';

                    const bookIdInput = document.createElement('input');
                    bookIdInput.type = 'hidden';
                    bookIdInput.name = 'book_id';
                    bookIdInput.value = bookId;

                    const borrowInput = document.createElement('input');
                    borrowInput.type = 'hidden';
                    borrowInput.name = 'borrow_book';
                    borrowInput.value = '1';

                    form.appendChild(bookIdInput);
                    form.appendChild(borrowInput);
                    document.body.appendChild(form);
                    form.submit();
                }, 1000);
            }
        });
    }

    // Add hover effects for book cards
    document.addEventListener('DOMContentLoaded', function() {
        const bookCards = document.querySelectorAll('.grid .border');
        bookCards.forEach(card => {
            card.addEventListener('mouseenter', function() {
                this.style.transform = 'translateY(-2px)';
            });
            card.addEventListener('mouseleave', function() {
                this.style.transform = 'translateY(0)';
            });
        });
    });
    </script>
</body>

</html>