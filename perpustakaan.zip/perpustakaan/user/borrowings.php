<?php
session_start();
require_once '../config.php';

// Cek apakah user sudah login
check_login();

// Update status overdue
update_overdue_books($conn);

$message = '';
$message_type = '';

// Handle pengembalian buku
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['return_book'])) {
    $borrowing_id = (int)$_POST['borrowing_id'];
    $result = return_book_with_fine($conn, $borrowing_id, $_SESSION['user_id']);

    $message = $result['message'];
    $message_type = $result['success'] ? 'success' : 'error';
}

// Ambil riwayat peminjaman user
$borrowings_query = "SELECT b.*, bk.title, bk.author, bk.isbn 
                     FROM borrowings b 
                     JOIN books bk ON b.book_id = bk.id 
                     WHERE b.user_id = ? 
                     ORDER BY b.created_at DESC";
$stmt = $conn->prepare($borrowings_query);
$stmt->bind_param("i", $_SESSION['user_id']);
$stmt->execute();
$borrowings_result = $stmt->get_result();

// Statistik user
$stats_query = "SELECT 
                    COUNT(*) as total_borrowed,
                    SUM(CASE WHEN status = 'borrowed' THEN 1 ELSE 0 END) as currently_borrowed,
                    SUM(CASE WHEN status = 'returned' THEN 1 ELSE 0 END) as returned,
                    SUM(CASE WHEN status = 'overdue' THEN 1 ELSE 0 END) as overdue,
                    SUM(CASE WHEN fine_amount > 0 AND fine_paid = 0 THEN fine_amount ELSE 0 END) as unpaid_fines
                FROM borrowings 
                WHERE user_id = ?";
$stmt = $conn->prepare($stats_query);
$stmt->bind_param("i", $_SESSION['user_id']);
$stmt->execute();
$stats_result = $stmt->get_result();
$stats = $stats_result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Peminjaman Saya - Perpustakaan</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link rel="stylesheet" href="../style-tailwind.css">
    <style>
    .borrowing-row {
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    }

    .borrowing-row:hover {
        transform: translateY(-1px);
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
    }

    @keyframes fadeIn {
        from {
            opacity: 0;
            transform: translateY(20px);
        }

        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    .animate-fade-in {
        animation: fadeIn 0.5s ease-out;
    }

    .stat-card {
        transition: all 0.3s ease;
    }

    .stat-card:hover {
        transform: translateY(-2px);
        box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
    }
    </style>
</head>

<body class="bg-gray-100">
    <div class="flex h-screen">
        <!-- Sidebar -->
        <div class="sidebar-gradient w-64 text-white flex flex-col">
            <div class="p-6 border-b border-white border-opacity-20">
                <h3 class="text-xl font-bold">📚 Perpustakaan</h3>
            </div>
            <nav class="flex-1 px-4 py-6 space-y-2">
                <a href="dashboard.php"
                    class="flex items-center px-4 py-3 text-white hover:bg-white hover:bg-opacity-10 rounded-lg transition-colors">
                    📖 Dashboard
                </a>
                <a href="borrowings.php"
                    class="flex items-center px-4 py-3 text-white bg-white bg-opacity-20 rounded-lg font-medium">
                    📋 Peminjaman Saya
                </a>
                <a href="profile.php"
                    class="flex items-center px-4 py-3 text-white hover:bg-white hover:bg-opacity-10 rounded-lg transition-colors">
                    👤 Profile Saya
                </a>
                <a href="../logout.php"
                    class="flex items-center px-4 py-3 text-white hover:bg-white hover:bg-opacity-10 rounded-lg transition-colors">
                    🚪 Logout
                </a>
            </nav>
        </div>

        <!-- Main Content -->
        <div class="flex-1 flex flex-col overflow-hidden">
            <!-- Header -->
            <div class="bg-white shadow-sm border-b border-gray-200 px-6 py-4">
                <div class="flex justify-between items-center">
                    <h1 class="text-2xl font-bold text-gray-900">Peminjaman Saya</h1>
                    <div class="flex items-center space-x-3">
                        <div
                            class="w-8 h-8 bg-gradient-to-r from-green-500 to-blue-600 rounded-full flex items-center justify-center text-white font-bold text-sm">
                            <?php echo strtoupper(substr($_SESSION['username'], 0, 1)); ?>
                        </div>
                        <div class="text-sm">
                            <div class="font-medium text-gray-900"><?php echo $_SESSION['username']; ?></div>
                            <div class="text-gray-500">User</div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Content -->
            <div class="flex-1 overflow-auto p-6">
                <?php if (!empty($message)): ?>
                <script>
                document.addEventListener('DOMContentLoaded', function() {
                    Swal.fire({
                        icon: '<?php echo $message_type == "success" ? "success" : "error"; ?>',
                        title: '<?php echo $message_type == "success" ? "Berhasil!" : "Error!"; ?>',
                        text: '<?php echo addslashes($message); ?>',
                        confirmButtonColor: '#3085d6',
                        customClass: {
                            popup: 'rounded-2xl shadow-2xl',
                            confirmButton: 'font-semibold px-6 py-3 rounded-lg'
                        },
                        backdrop: `rgba(0,0,0,0.4)`
                    });
                });
                </script>
                <?php endif; ?>

                <!-- Statistics Grid -->
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6 mb-6">
                    <div class="stat-card bg-black rounded-lg shadow-sm p-6 animate-fade-in">
                        <div class="flex items-center">
                            <div class="p-2 bg-blue-100 rounded-lg">
                                <svg class="w-6 h-6 text-blue-600" fill="none" stroke="currentColor"
                                    viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z">
                                    </path>
                                </svg>
                            </div>
                            <div class="ml-4">
                                <p class="text-sm font-bold text-white ">Total Pinjam</p>
                                <p class="text-2xl font-bold text-white"><?php echo $stats['total_borrowed'] ?? 0; ?>
                                </p>
                            </div>
                        </div>
                    </div>

                    <div class="stat-card bg-white rounded-lg shadow-sm p-6 animate-fade-in">
                        <div class="flex items-center">
                            <div class="p-2 bg-yellow-100 rounded-lg">
                                <svg class="w-6 h-6 text-yellow-600" fill="none" stroke="currentColor"
                                    viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                </svg>
                            </div>
                            <div class="ml-4">
                                <p class="text-sm font-bold text-white">Sedang Dipinjam</p>
                                <p class="text-2xl font-bold text-white">
                                    <?php echo $stats['currently_borrowed'] ?? 0; ?></p>
                            </div>
                        </div>
                    </div>

                    <div class="stat-card bg-white rounded-lg shadow-sm p-6 animate-fade-in">
                        <div class="flex items-center">
                            <div class="p-2 bg-green-100 rounded-lg">
                                <svg class="w-6 h-6 text-green-600" fill="none" stroke="currentColor"
                                    viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M5 13l4 4L19 7"></path>
                                </svg>
                            </div>
                            <div class="ml-4">
                                <p class="text-sm font-medium text-white">Sudah Dikembalikan</p>
                                <p class="text-2xl font-bold text-white"><?php echo $stats['returned'] ?? 0; ?></p>
                            </div>
                        </div>
                    </div>

                    <div class="stat-card bg-white rounded-lg shadow-sm p-6 animate-fade-in">
                        <div class="flex items-center">
                            <div class="p-2 bg-red-100 rounded-lg">
                                <svg class="w-6 h-6 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L3.732 16.5c-.77.833.192 2.5 1.732 2.5z">
                                    </path>
                                </svg>
                            </div>
                            <div class="ml-4">
                                <p class="text-sm font-medium text-white">Terlambat</p>
                                <p class="text-2xl font-bold text-white"><?php echo $stats['overdue'] ?? 0; ?></p>
                            </div>
                        </div>
                    </div>

                    <div class="stat-card bg-white rounded-lg shadow-sm p-6 animate-fade-in">
                        <div class="flex items-center">
                            <div class="p-2 bg-orange-100 rounded-lg">
                                <svg class="w-6 h-6 text-orange-600" fill="none" stroke="currentColor"
                                    viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1">
                                    </path>
                                </svg>
                            </div>
                            <div class="ml-4">
                                <p class="text-sm font-medium text-white">Denda Belum Bayar</p>
                                <p class="text-xl font-bold text-white">Rp
                                    <?php echo number_format($stats['unpaid_fines'] ?? 0, 0, ',', '.'); ?></p>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Borrowings Table -->
                <div class="bg-white rounded-lg shadow-sm overflow-hidden mb-6">
                    <div class="px-6 py-4 border-b border-gray-200">
                        <h2 class="text-lg font-medium text-gray-900">Riwayat Peminjaman</h2>
                    </div>
                    <div class="overflow-x-auto">
                        <table class="min-w-full divide-y divide-gray-200">
                            <thead class="bg-gray-50">
                                <tr>
                                    <th
                                        class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Buku</th>
                                    <th
                                        class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Penulis</th>
                                    <th
                                        class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Tanggal Pinjam</th>
                                    <th
                                        class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Jatuh Tempo</th>
                                    <th
                                        class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Tanggal Kembali</th>
                                    <th
                                        class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Denda</th>
                                    <th
                                        class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Status</th>
                                    <th
                                        class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Aksi</th>
                                </tr>
                            </thead>
                            <tbody class="bg-white divide-y divide-gray-200">
                                <?php if ($borrowings_result->num_rows > 0): ?>
                                <?php while ($borrowing = $borrowings_result->fetch_assoc()): ?>
                                <tr class="borrowing-row hover:bg-gray-50">
                                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900 cursor-pointer"
                                        onclick="showBorrowingDetail({
                                            id: <?php echo $borrowing['id']; ?>,
                                            title: '<?php echo addslashes(htmlspecialchars($borrowing['title'])); ?>',
                                            author: '<?php echo addslashes(htmlspecialchars($borrowing['author'])); ?>',
                                            isbn: '<?php echo addslashes(htmlspecialchars($borrowing['isbn'] ?? '')); ?>',
                                            borrow_date: '<?php echo date('d/m/Y', strtotime($borrowing['borrow_date'])); ?>',
                                            due_date: '<?php echo date('d/m/Y', strtotime($borrowing['due_date'])); ?>',
                                            return_date: '<?php echo $borrowing['return_date'] ? date('d/m/Y', strtotime($borrowing['return_date'])) : ''; ?>',
                                            status: '<?php echo $borrowing['status']; ?>',
                                            fine_amount: <?php echo $borrowing['fine_amount'] ?? 0; ?>,
                                            fine_paid: <?php echo $borrowing['fine_paid'] ?? 0; ?>
                                        })" title="Klik untuk melihat detail">
                                        <div class="flex items-center">
                                            <span class="hover:text-blue-600 transition-colors">
                                                <?php echo htmlspecialchars($borrowing['title']); ?>
                                            </span>
                                            <span class="ml-2 text-xs text-gray-400">📖</span>
                                        </div>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                        <?php echo htmlspecialchars($borrowing['author']); ?></td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                        <?php echo date('d/m/Y', strtotime($borrowing['borrow_date'])); ?></td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm">
                                        <?php
                                                $due_date = date('d/m/Y', strtotime($borrowing['due_date']));
                                                $is_overdue = ($borrowing['status'] == 'overdue' ||
                                                    ($borrowing['status'] == 'borrowed' && strtotime($borrowing['due_date']) < time()));
                                                if ($is_overdue && $borrowing['status'] == 'borrowed') {
                                                    echo "<span class='text-red-600 font-bold'>" . $due_date . "</span>";
                                                } else {
                                                    echo "<span class='text-gray-500'>" . $due_date . "</span>";
                                                }
                                                ?>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                        <?php
                                                if ($borrowing['return_date']) {
                                                    echo date('d/m/Y', strtotime($borrowing['return_date']));
                                                } else {
                                                    echo '-';
                                                }
                                                ?>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm">
                                        <?php
                                                $current_fine = 0;
                                                if ($borrowing['status'] == 'overdue' || ($borrowing['status'] == 'returned' && $borrowing['fine_amount'] > 0)) {
                                                    $current_fine = $borrowing['fine_amount'] > 0 ? $borrowing['fine_amount'] : calculate_fine($borrowing['due_date']);
                                                }

                                                if ($current_fine > 0): ?>
                                        <div class="flex flex-col">
                                            <span class="text-red-600 font-bold">Rp
                                                <?php echo number_format($current_fine, 0, ',', '.'); ?></span>
                                            <?php if ($borrowing['fine_paid'] == 1): ?>
                                            <span class="text-xs text-green-600">✓ Sudah Bayar</span>
                                            <?php elseif ($borrowing['status'] == 'returned'): ?>
                                            <span class="text-xs text-red-600">⚠ Belum Bayar</span>
                                            <?php else: ?>
                                            <span class="text-xs text-orange-600">• Berjalan</span>
                                            <?php endif; ?>
                                        </div>
                                        <?php else: ?>
                                        <span class="text-gray-400">-</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <?php
                                                $status_class = '';
                                                $status_text = '';
                                                switch ($borrowing['status']) {
                                                    case 'borrowed':
                                                        $status_class = 'bg-blue-100 text-blue-800';
                                                        $status_text = 'Dipinjam';
                                                        break;
                                                    case 'returned':
                                                        $status_class = 'bg-green-100 text-green-800';
                                                        $status_text = 'Dikembalikan';
                                                        break;
                                                    case 'overdue':
                                                        $status_class = 'bg-red-100 text-red-800';
                                                        $status_text = 'Terlambat';
                                                        break;
                                                }
                                                ?>
                                        <span
                                            class="inline-flex px-2 py-1 text-xs font-semibold rounded-full <?php echo $status_class; ?>"><?php echo $status_text; ?></span>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                        <?php if ($borrowing['status'] == 'borrowed' || $borrowing['status'] == 'overdue'): ?>
                                        <button type="button"
                                            onclick="confirmReturnBook(<?php echo $borrowing['id']; ?>, '<?php echo addslashes(htmlspecialchars($borrowing['title'])); ?>', '<?php echo $borrowing['status']; ?>')"
                                            class="bg-green-600 hover:bg-green-700 text-white px-3 py-1 rounded text-sm font-medium transition-colors">
                                            📤 Kembalikan
                                        </button>
                                        <?php else: ?>
                                        <span class="text-gray-400">-</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                                <?php else: ?>
                                <tr>
                                    <td colspan="8" class="px-6 py-4 text-center text-sm text-gray-500">Belum ada
                                        riwayat peminjaman</td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- Information Box -->
                <div class="bg-white rounded-lg shadow-sm p-6">
                    <h3 class="text-lg font-medium text-gray-900 mb-4">Informasi Peminjaman</h3>
                    <ul class="space-y-2 text-sm text-gray-600">
                        <li class="flex items-start">
                            <span class="w-2 h-2 bg-blue-500 rounded-full mt-2 mr-3 flex-shrink-0"></span>
                            Setiap buku dapat dipinjam maksimal 7 hari
                        </li>
                        <li class="flex items-start">
                            <span class="w-2 h-2 bg-red-500 rounded-full mt-2 mr-3 flex-shrink-0"></span>
                            <strong>Denda keterlambatan: Rp 2.000 per hari</strong>
                        </li>
                        <li class="flex items-start">
                            <span class="w-2 h-2 bg-blue-500 rounded-full mt-2 mr-3 flex-shrink-0"></span>
                            Pengembalian terlambat akan dikenakan denda yang harus dibayar
                        </li>
                        <li class="flex items-start">
                            <span class="w-2 h-2 bg-blue-500 rounded-full mt-2 mr-3 flex-shrink-0"></span>
                            Anda tidak dapat meminjam buku yang sama jika masih dalam status dipinjam
                        </li>
                        <li class="flex items-start">
                            <span class="w-2 h-2 bg-blue-500 rounded-full mt-2 mr-3 flex-shrink-0"></span>
                            Pastikan mengembalikan buku tepat waktu untuk menghindari denda
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <script>
    // Function to show borrowing detail modal
    function showBorrowingDetail(borrowingData) {
        const statusColors = {
            'borrowed': {
                bg: 'bg-blue-50',
                text: 'text-blue-600',
                border: 'border-blue-200'
            },
            'returned': {
                bg: 'bg-green-50',
                text: 'text-green-600',
                border: 'border-green-200'
            },
            'overdue': {
                bg: 'bg-red-50',
                text: 'text-red-600',
                border: 'border-red-200'
            }
        };

        const statusText = {
            'borrowed': '📚 Sedang Dipinjam',
            'returned': '✅ Sudah Dikembalikan',
            'overdue': '⚠️ Terlambat'
        };

        const statusColor = statusColors[borrowingData.status] || statusColors['borrowed'];

        const borrowingInfo = `
                <div class="text-left space-y-4">
                    <div class="border-b pb-4 mb-4">
                        <h3 class="text-xl font-bold text-gray-800 mb-2">${borrowingData.title}</h3>
                        <p class="text-gray-600 font-medium">oleh ${borrowingData.author}</p>
                        ${borrowingData.isbn ? `<p class="text-sm text-gray-500 mt-1">ISBN: ${borrowingData.isbn}</p>` : ''}
                    </div>
                    
                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm">
                        <div class="bg-blue-50 p-3 rounded-lg border border-blue-200">
                            <span class="font-semibold text-gray-700 block mb-1">📅 Tanggal Pinjam:</span>
                            <span class="text-gray-600">${borrowingData.borrow_date}</span>
                        </div>
                        
                        <div class="bg-orange-50 p-3 rounded-lg border border-orange-200">
                            <span class="font-semibold text-gray-700 block mb-1">⏰ Jatuh Tempo:</span>
                            <span class="text-gray-600">${borrowingData.due_date}</span>
                        </div>
                        
                        ${borrowingData.return_date ? `
                        <div class="bg-green-50 p-3 rounded-lg border border-green-200">
                            <span class="font-semibold text-gray-700 block mb-1">📤 Tanggal Kembali:</span>
                            <span class="text-gray-600">${borrowingData.return_date}</span>
                        </div>
                        ` : ''}
                        
                        <div class="${statusColor.bg} p-3 rounded-lg border ${statusColor.border}">
                            <span class="font-semibold text-gray-700 block mb-1">📊 Status:</span>
                            <span class="font-medium ${statusColor.text}">${statusText[borrowingData.status]}</span>
                        </div>
                    </div>
                    
                    ${borrowingData.fine_amount > 0 ? `
                    <div class="mt-4 pt-4 border-t bg-red-50 p-4 rounded-lg border border-red-200">
                        <span class="font-semibold text-red-700 block mb-2">💰 Informasi Denda:</span>
                        <div class="space-y-1">
                            <p class="text-red-600"><strong>Jumlah Denda: Rp ${new Intl.NumberFormat('id-ID').format(borrowingData.fine_amount)}</strong></p>
                            <p class="text-sm ${borrowingData.fine_paid == 1 ? 'text-green-600' : 'text-red-600'}">
                                Status: ${borrowingData.fine_paid == 1 ? '✅ Sudah Dibayar' : '❌ Belum Dibayar'}
                            </p>
                        </div>
                    </div>
                    ` : ''}
                    
                    <div class="mt-4 pt-4 border-t bg-gray-50 p-4 rounded-lg">
                        <p class="text-xs text-gray-600">
                            <strong>💡 Tips:</strong> Kembalikan buku tepat waktu untuk menghindari denda keterlambatan sebesar Rp 2.000/hari.
                        </p>
                    </div>
                </div>
            `;

        const showReturnButton = borrowingData.status === 'borrowed' || borrowingData.status === 'overdue';

        Swal.fire({
            title: '<div class="flex items-center gap-2"><span class="text-2xl">📚</span><span>Detail Peminjaman</span></div>',
            html: borrowingInfo,
            width: 700,
            showCancelButton: showReturnButton,
            confirmButtonText: showReturnButton ? '<i class="mr-2">📤</i> Kembalikan Buku' :
                '<i class="mr-2">✅</i> Tutup',
            cancelButtonText: '<i class="mr-2">❌</i> Tutup',
            confirmButtonColor: showReturnButton ? '#dc2626' : '#6b7280',
            cancelButtonColor: '#6b7280',
            showCloseButton: true,
            customClass: {
                popup: 'rounded-2xl shadow-2xl',
                title: 'text-lg font-bold text-gray-800',
                confirmButton: 'font-semibold px-6 py-3 rounded-lg',
                cancelButton: 'font-semibold px-6 py-3 rounded-lg'
            },
            backdrop: `rgba(0,0,0,0.4)`,
            allowOutsideClick: true,
            allowEscapeKey: true
        }).then((result) => {
            if (result.isConfirmed && showReturnButton) {
                confirmReturnBook(borrowingData.id, borrowingData.title, borrowingData.status);
            }
        });
    }

    // Function to confirm book return
    function confirmReturnBook(borrowingId, bookTitle, status) {
        const isOverdue = status === 'overdue';

        Swal.fire({
            title: '<div class="flex items-center gap-2"><span class="text-2xl">📤</span><span>Konfirmasi Pengembalian</span></div>',
            html: `
                    <div class="text-center p-4">
                        <div class="mb-4 p-4 ${isOverdue ? 'bg-red-50 border border-red-200' : 'bg-blue-50 border border-blue-200'} rounded-xl">
                            <p class="text-gray-700 mb-2">Apakah Anda yakin ingin mengembalikan buku:</p>
                            <p class="font-bold ${isOverdue ? 'text-red-600' : 'text-blue-600'} text-lg">"${bookTitle}"</p>
                        </div>
                        
                        ${isOverdue ? `
                        <div class="text-sm text-red-600 bg-red-50 p-3 rounded-lg border border-red-200 mb-4">
                            <p class="font-medium text-red-700 mb-1">⚠️ Peringatan Keterlambatan:</p>
                            <ul class="text-left list-disc list-inside space-y-1">
                                <li>Buku ini sudah melewati batas waktu pengembalian</li>
                                <li>Anda akan dikenakan denda keterlambatan</li>
                                <li>Denda akan dihitung otomatis saat pengembalian</li>
                            </ul>
                        </div>
                        ` : `
                        <div class="text-sm text-green-600 bg-green-50 p-3 rounded-lg border border-green-200 mb-4">
                            <p class="font-medium text-green-700 mb-1">✅ Pengembalian Tepat Waktu:</p>
                            <p>Terima kasih telah mengembalikan buku tepat waktu!</p>
                        </div>
                        `}
                        
                        <div class="text-xs text-gray-600 bg-gray-50 p-3 rounded-lg">
                            <p class="font-medium text-gray-700 mb-1">📋 Prosedur Pengembalian:</p>
                            <ul class="text-left list-disc list-inside space-y-1">
                                <li>Pastikan kondisi buku masih baik</li>
                                <li>Sistem akan memproses pengembalian otomatis</li>
                                <li>Denda (jika ada) akan tercatat dalam sistem</li>
                            </ul>
                        </div>
                    </div>
                `,
            icon: isOverdue ? 'warning' : 'question',
            showCancelButton: true,
            confirmButtonText: '<i class="mr-2">✅</i> Ya, Kembalikan Buku!',
            cancelButtonText: '<i class="mr-2">❌</i> Batal',
            confirmButtonColor: isOverdue ? '#dc2626' : '#10b981',
            cancelButtonColor: '#6b7280',
            reverseButtons: true,
            customClass: {
                popup: 'rounded-2xl shadow-2xl',
                confirmButton: 'font-semibold px-6 py-3 rounded-lg',
                cancelButton: 'font-semibold px-6 py-3 rounded-lg'
            },
            backdrop: `rgba(0,0,0,0.4)`
        }).then((result) => {
            if (result.isConfirmed) {
                // Show loading with animation
                Swal.fire({
                    title: '<div class="flex items-center gap-2"><span class="text-2xl">⏳</span><span>Memproses Pengembalian...</span></div>',
                    html: `
                            <div class="text-center p-4">
                                <div class="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mb-4"></div>
                                <p class="text-gray-600">Sedang memproses pengembalian buku</p>
                                <p class="text-sm text-gray-500 mt-2">"${bookTitle}"</p>
                                ${isOverdue ? '<p class="text-xs text-red-500 mt-1">Menghitung denda keterlambatan...</p>' : ''}
                            </div>
                        `,
                    allowOutsideClick: false,
                    allowEscapeKey: false,
                    showConfirmButton: false,
                    customClass: {
                        popup: 'rounded-2xl shadow-2xl'
                    },
                    backdrop: `rgba(0,0,0,0.6)`
                });

                // Submit the form after a small delay for better UX
                setTimeout(() => {
                    const form = document.createElement('form');
                    form.method = 'POST';
                    form.style.display = 'none';

                    const borrowingIdInput = document.createElement('input');
                    borrowingIdInput.type = 'hidden';
                    borrowingIdInput.name = 'borrowing_id';
                    borrowingIdInput.value = borrowingId;

                    const returnInput = document.createElement('input');
                    returnInput.type = 'hidden';
                    returnInput.name = 'return_book';
                    returnInput.value = '1';

                    form.appendChild(borrowingIdInput);
                    form.appendChild(returnInput);
                    document.body.appendChild(form);
                    form.submit();
                }, 1500);
            }
        });
    }

    // Add initialization when page loads
    document.addEventListener('DOMContentLoaded', function() {
        // Add stagger animation to stat cards
        const statCards = document.querySelectorAll('.stat-card');
        statCards.forEach((card, index) => {
            card.style.animationDelay = `${index * 0.1}s`;
        });

        // Add hover effect to borrowing rows
        const borrowingRows = document.querySelectorAll('.borrowing-row');
        borrowingRows.forEach(row => {
            row.addEventListener('mouseenter', function() {
                this.style.backgroundColor = '#f9fafb';
            });
            row.addEventListener('mouseleave', function() {
                this.style.backgroundColor = '';
            });
        });
    });
    </script>
</body>

</html>