<?php
session_start();
require_once '../config.php';

// Cek apakah user sudah login
check_login();

$message = '';
$message_type = '';

// Handle form submissions
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['update_profile'])) {
        $username = clean_input($_POST['username']);
        $email = clean_input($_POST['email']);

        // Validasi input
        if (empty($username) || empty($email)) {
            $message = "Username dan email harus diisi!";
            $message_type = "error";
        } else {
            // Cek apakah username atau email sudah ada (kecuali untuk user yang sedang login)
            $check_query = "SELECT id FROM users WHERE (username = ? OR email = ?) AND id != ?";
            $stmt = $conn->prepare($check_query);
            $stmt->bind_param("ssi", $username, $email, $_SESSION['user_id']);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                $message = "Username atau email sudah digunakan user lain!";
                $message_type = "error";
            } else {
                // Update profile
                $update_query = "UPDATE users SET username=?, email=? WHERE id=?";
                $stmt = $conn->prepare($update_query);
                $stmt->bind_param("ssi", $username, $email, $_SESSION['user_id']);

                if ($stmt->execute()) {
                    $_SESSION['username'] = $username; // Update session
                    $message = "Profile berhasil diperbarui!";
                    $message_type = "success";
                } else {
                    $message = "Gagal memperbarui profile: " . $conn->error;
                    $message_type = "error";
                }
            }
        }
    }

    if (isset($_POST['change_password'])) {
        $current_password = clean_input($_POST['current_password']);
        $new_password = clean_input($_POST['new_password']);
        $confirm_password = clean_input($_POST['confirm_password']);

        // Validasi input
        if (empty($current_password) || empty($new_password) || empty($confirm_password)) {
            $message = "Semua field password harus diisi!";
            $message_type = "error";
        } elseif ($new_password != $confirm_password) {
            $message = "Password baru dan konfirmasi password tidak cocok!";
            $message_type = "error";
        } elseif (strlen($new_password) < 6) {
            $message = "Password baru minimal 6 karakter!";
            $message_type = "error";
        } else {
            // Cek password lama
            $check_query = "SELECT password FROM users WHERE id = ?";
            $stmt = $conn->prepare($check_query);
            $stmt->bind_param("i", $_SESSION['user_id']);
            $stmt->execute();
            $result = $stmt->get_result();
            $user_data = $result->fetch_assoc();

            if (hash_password($current_password) != $user_data['password']) {
                $message = "Password lama tidak sesuai!";
                $message_type = "error";
            } else {
                // Update password
                $hashed_new_password = hash_password($new_password);
                $update_query = "UPDATE users SET password=? WHERE id=?";
                $stmt = $conn->prepare($update_query);
                $stmt->bind_param("si", $hashed_new_password, $_SESSION['user_id']);

                if ($stmt->execute()) {
                    $message = "Password berhasil diubah!";
                    $message_type = "success";
                } else {
                    $message = "Gagal mengubah password: " . $conn->error;
                    $message_type = "error";
                }
            }
        }
    }
}

// Get current user data
$user_query = "SELECT * FROM users WHERE id = ?";
$stmt = $conn->prepare($user_query);
$stmt->bind_param("i", $_SESSION['user_id']);
$stmt->execute();
$result = $stmt->get_result();
$user_data = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile Saya - Perpustakaan</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link rel="stylesheet" href="../style-tailwind.css">
    <style>
    .profile-card {
        transition: all 0.3s ease;
    }

    .profile-card:hover {
        transform: translateY(-2px);
        box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
    }

    @keyframes fadeIn {
        from {
            opacity: 0;
            transform: translateY(20px);
        }

        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    .animate-fade-in {
        animation: fadeIn 0.5s ease-out;
    }

    .form-input {
        transition: all 0.3s ease;
    }

    .form-input:focus {
        transform: translateY(-1px);
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
    }
    </style>
</head>

<body class="bg-gray-100">
    <div class="flex h-screen">
        <!-- Sidebar -->
        <div class="sidebar-gradient w-64 text-white flex flex-col">
            <div class="p-6 border-b border-white border-opacity-20">
                <h3 class="text-xl font-bold">📚 Perpustakaan</h3>
            </div>
            <nav class="flex-1 px-4 py-6 space-y-2">
                <a href="dashboard.php"
                    class="flex items-center px-4 py-3 text-white hover:bg-white hover:bg-opacity-10 rounded-lg transition-colors">
                    📖 Dashboard
                </a>
                <a href="borrowings.php"
                    class="flex items-center px-4 py-3 text-white hover:bg-white hover:bg-opacity-10 rounded-lg transition-colors">
                    📋 Peminjaman Saya
                </a>
                <a href="profile.php"
                    class="flex items-center px-4 py-3 text-white bg-white bg-opacity-20 rounded-lg font-medium">
                    👤 Profile Saya
                </a>
                <a href="../logout.php"
                    class="flex items-center px-4 py-3 text-white hover:bg-white hover:bg-opacity-10 rounded-lg transition-colors">
                    🚪 Logout
                </a>
            </nav>
        </div>

        <!-- Main Content -->
        <div class="flex-1 flex flex-col overflow-hidden">
            <!-- Header -->
            <div class="bg-white shadow-sm border-b border-gray-200 px-6 py-4">
                <div class="flex justify-between items-center">
                    <h1 class="text-2xl font-bold text-gray-900">Profile Saya</h1>
                    <div class="flex items-center space-x-3">
                        <div
                            class="w-8 h-8 bg-gradient-to-r from-green-500 to-blue-600 rounded-full flex items-center justify-center text-white font-bold text-sm">
                            <?php echo strtoupper(substr($_SESSION['username'], 0, 1)); ?>
                        </div>
                        <div class="text-sm">
                            <div class="font-medium text-gray-900"><?php echo $_SESSION['username']; ?></div>
                            <div class="text-gray-500">User</div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Content -->
            <div class="flex-1 overflow-auto p-6">
                <?php if (!empty($message)): ?>
                <script>
                document.addEventListener('DOMContentLoaded', function() {
                    Swal.fire({
                        icon: '<?php echo $message_type == "success" ? "success" : "error"; ?>',
                        title: '<?php echo $message_type == "success" ? "Berhasil!" : "Error!"; ?>',
                        text: '<?php echo addslashes($message); ?>',
                        confirmButtonColor: '#3085d6',
                        customClass: {
                            popup: 'rounded-2xl shadow-2xl',
                            confirmButton: 'font-semibold px-6 py-3 rounded-lg'
                        },
                        backdrop: `rgba(0,0,0,0.4)`
                    });
                });
                </script>
                <?php endif; ?>

                <!-- Welcome Section -->
                <div class="bg-white rounded-lg shadow-sm p-6 mb-6 animate-fade-in">
                    <div class="flex items-center space-x-4">
                        <div
                            class="w-16 h-16 bg-gradient-to-r from-green-500 to-blue-600 rounded-full flex items-center justify-center text-white font-bold text-2xl">
                            <?php echo strtoupper(substr($user_data['username'], 0, 1)); ?>
                        </div>
                        <div>
                            <h2 class="text-xl font-bold text-gray-900">
                                <?php echo htmlspecialchars($user_data['username']); ?></h2>
                            <p class="text-gray-600"><?php echo htmlspecialchars($user_data['email']); ?></p>
                            <p class="text-sm text-gray-500">Bergabung:
                                <?php echo date('d F Y', strtotime($user_data['created_at'])); ?></p>
                        </div>
                    </div>
                </div>

                <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    <!-- Update Profile Form -->
                    <div class="profile-card bg-white rounded-lg shadow-sm p-6 animate-fade-in">
                        <div class="flex items-center mb-6">
                            <div class="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center mr-3">
                                <svg class="w-6 h-6 text-blue-600" fill="none" stroke="currentColor"
                                    viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path>
                                </svg>
                            </div>
                            <div>
                                <h3 class="text-lg font-medium text-gray-900">Update Profile</h3>
                                <p class="text-sm text-gray-600">Perbarui informasi akun Anda</p>
                            </div>
                        </div>

                        <form method="POST" class="space-y-4">
                            <div>
                                <label for="username" class="block text-sm font-medium text-gray-700 mb-2">
                                    Username
                                </label>
                                <input type="text" id="username" name="username" required
                                    value="<?php echo htmlspecialchars($user_data['username']); ?>"
                                    class="form-input w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500">
                            </div>

                            <div>
                                <label for="email" class="block text-sm font-medium text-gray-700 mb-2">
                                    Email
                                </label>
                                <input type="email" id="email" name="email" required
                                    value="<?php echo htmlspecialchars($user_data['email']); ?>"
                                    class="form-input w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500">
                            </div>

                            <button type="submit" name="update_profile"
                                class="w-full bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg font-medium transition-colors flex items-center justify-center space-x-2">
                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12"></path>
                                </svg>
                                <span>Perbarui Profile</span>
                            </button>
                        </form>
                    </div>

                    <!-- Change Password Form -->
                    <div class="profile-card bg-white rounded-lg shadow-sm p-6 animate-fade-in">
                        <div class="flex items-center mb-6">
                            <div class="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center mr-3">
                                <svg class="w-6 h-6 text-green-600" fill="none" stroke="currentColor"
                                    viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z">
                                    </path>
                                </svg>
                            </div>
                            <div>
                                <h3 class="text-lg font-medium text-gray-900">Ubah Password</h3>
                                <p class="text-sm text-gray-600">Ganti password untuk keamanan akun</p>
                            </div>
                        </div>

                        <form method="POST" class="space-y-4">
                            <div>
                                <label for="current_password" class="block text-sm font-medium text-gray-700 mb-2">
                                    Password Lama
                                </label>
                                <input type="password" id="current_password" name="current_password" required
                                    class="form-input w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-green-500 focus:border-green-500"
                                    placeholder="Masukkan password lama">
                            </div>

                            <div>
                                <label for="new_password" class="block text-sm font-medium text-gray-700 mb-2">
                                    Password Baru
                                </label>
                                <input type="password" id="new_password" name="new_password" required
                                    class="form-input w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-green-500 focus:border-green-500"
                                    placeholder="Minimal 6 karakter">
                            </div>

                            <div>
                                <label for="confirm_password" class="block text-sm font-medium text-gray-700 mb-2">
                                    Konfirmasi Password Baru
                                </label>
                                <input type="password" id="confirm_password" name="confirm_password" required
                                    class="form-input w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-green-500 focus:border-green-500"
                                    placeholder="Ulangi password baru">
                            </div>

                            <button type="submit" name="change_password"
                                class="w-full bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg font-medium transition-colors flex items-center justify-center space-x-2">
                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z">
                                    </path>
                                </svg>
                                <span>Ubah Password</span>
                            </button>
                        </form>
                    </div>
                </div>

                <!-- Account Information -->
                <div class="bg-white rounded-lg shadow-sm p-6 mt-6 animate-fade-in">
                    <h3 class="text-lg font-medium text-gray-900 mb-4">Informasi Akun</h3>
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div class="bg-blue-50 p-4 rounded-lg border border-blue-200">
                            <div class="flex items-center">
                                <div class="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center mr-3">
                                    <svg class="w-5 h-5 text-blue-600" fill="none" stroke="currentColor"
                                        viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                            d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z">
                                        </path>
                                    </svg>
                                </div>
                                <div>
                                    <p class="text-sm font-medium text-blue-900">Role</p>
                                    <p class="text-lg font-bold text-blue-600">
                                        <?php echo ucfirst($user_data['role']); ?></p>
                                </div>
                            </div>
                        </div>

                        <div class="bg-green-50 p-4 rounded-lg border border-green-200">
                            <div class="flex items-center">
                                <div class="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center mr-3">
                                    <svg class="w-5 h-5 text-green-600" fill="none" stroke="currentColor"
                                        viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                            d="M8 7V3a1 1 0 012 0v4h4V3a1 1 0 012 0v4h2a1 1 0 011 1v11a1 1 0 01-1 1H6a1 1 0 01-1-1V8a1 1 0 011-1h2z">
                                        </path>
                                    </svg>
                                </div>
                                <div>
                                    <p class="text-sm font-medium text-green-900">Bergabung</p>
                                    <p class="text-lg font-bold text-green-600">
                                        <?php echo date('d/m/Y', strtotime($user_data['created_at'])); ?></p>
                                </div>
                            </div>
                        </div>

                        <div class="bg-purple-50 p-4 rounded-lg border border-purple-200">
                            <div class="flex items-center">
                                <div class="w-8 h-8 bg-purple-100 rounded-lg flex items-center justify-center mr-3">
                                    <svg class="w-5 h-5 text-purple-600" fill="none" stroke="currentColor"
                                        viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                            d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                    </svg>
                                </div>
                                <div>
                                    <p class="text-sm font-medium text-purple-900">Status Akun</p>
                                    <p class="text-lg font-bold text-purple-600">Aktif</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Security Tips -->
                <div class="bg-white rounded-lg shadow-sm p-6 mt-6 animate-fade-in">
                    <h3 class="text-lg font-medium text-gray-900 mb-4">Tips Keamanan</h3>
                    <ul class="space-y-2 text-sm text-gray-600">
                        <li class="flex items-start">
                            <span class="w-2 h-2 bg-blue-500 rounded-full mt-2 mr-3 flex-shrink-0"></span>
                            Gunakan password yang kuat dengan minimal 6 karakter
                        </li>
                        <li class="flex items-start">
                            <span class="w-2 h-2 bg-blue-500 rounded-full mt-2 mr-3 flex-shrink-0"></span>
                            Jangan gunakan password yang sama dengan akun lain
                        </li>
                        <li class="flex items-start">
                            <span class="w-2 h-2 bg-blue-500 rounded-full mt-2 mr-3 flex-shrink-0"></span>
                            Perbarui password secara berkala untuk keamanan
                        </li>
                        <li class="flex items-start">
                            <span class="w-2 h-2 bg-blue-500 rounded-full mt-2 mr-3 flex-shrink-0"></span>
                            Jangan bagikan informasi login Anda kepada orang lain
                        </li>
                        <li class="flex items-start">
                            <span class="w-2 h-2 bg-blue-500 rounded-full mt-2 mr-3 flex-shrink-0"></span>
                            Logout dari akun setelah selesai menggunakan sistem
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <script>
    // Add real-time password validation
    document.addEventListener('DOMContentLoaded', function() {
        const newPasswordInput = document.getElementById('new_password');
        const confirmPasswordInput = document.getElementById('confirm_password');

        function validatePasswords() {
            const newPassword = newPasswordInput.value;
            const confirmPassword = confirmPasswordInput.value;

            if (newPassword.length > 0 && newPassword.length < 6) {
                newPasswordInput.style.borderColor = '#ef4444';
                newPasswordInput.style.backgroundColor = '#fef2f2';
            } else if (newPassword.length >= 6) {
                newPasswordInput.style.borderColor = '#10b981';
                newPasswordInput.style.backgroundColor = '#f0fdf4';
            } else {
                newPasswordInput.style.borderColor = '#d1d5db';
                newPasswordInput.style.backgroundColor = '#ffffff';
            }

            if (confirmPassword.length > 0) {
                if (newPassword === confirmPassword) {
                    confirmPasswordInput.style.borderColor = '#10b981';
                    confirmPasswordInput.style.backgroundColor = '#f0fdf4';
                } else {
                    confirmPasswordInput.style.borderColor = '#ef4444';
                    confirmPasswordInput.style.backgroundColor = '#fef2f2';
                }
            } else {
                confirmPasswordInput.style.borderColor = '#d1d5db';
                confirmPasswordInput.style.backgroundColor = '#ffffff';
            }
        }

        newPasswordInput.addEventListener('input', validatePasswords);
        confirmPasswordInput.addEventListener('input', validatePasswords);

        // Add animation to cards
        const cards = document.querySelectorAll('.profile-card');
        cards.forEach((card, index) => {
            card.style.animationDelay = `${index * 0.1}s`;
        });
    });
    </script>
</body>

</html>