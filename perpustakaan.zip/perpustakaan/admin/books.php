<?php
session_start();
require_once '../config.php';

// Cek apakah user adalah admin
check_admin();

$message = '';
$message_type = '';
$action = isset($_GET['action']) ? $_GET['action'] : 'list';
$book_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Handle form submissions
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['add_book'])) {
        $title = clean_input($_POST['title']);
        $author = clean_input($_POST['author']);
        $isbn = clean_input($_POST['isbn']);
        $publisher = clean_input($_POST['publisher']);
        $year_published = clean_input($_POST['year_published']);
        $stock = (int)$_POST['stock'];
        $description = clean_input($_POST['description']);

        $insert_query = "INSERT INTO books (title, author, isbn, publisher, year_published, stock, description) VALUES (?, ?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($insert_query);
        $stmt->bind_param("sssssis", $title, $author, $isbn, $publisher, $year_published, $stock, $description);

        if ($stmt->execute()) {
            $message = "Buku berhasil ditambahkan!";
            $message_type = "success";
            $action = 'list';
        } else {
            $message = "Gagal menambahkan buku: " . $conn->error;
            $message_type = "error";
        }
    }

    if (isset($_POST['update_book'])) {
        $id = (int)$_POST['id'];
        $title = clean_input($_POST['title']);
        $author = clean_input($_POST['author']);
        $isbn = clean_input($_POST['isbn']);
        $publisher = clean_input($_POST['publisher']);
        $year_published = clean_input($_POST['year_published']);
        $stock = (int)$_POST['stock'];
        $description = clean_input($_POST['description']);

        $update_query = "UPDATE books SET title=?, author=?, isbn=?, publisher=?, year_published=?, stock=?, description=?, updated_at=CURRENT_TIMESTAMP WHERE id=?";
        $stmt = $conn->prepare($update_query);
        $stmt->bind_param("ssssssii", $title, $author, $isbn, $publisher, $year_published, $stock, $description, $id);

        if ($stmt->execute()) {
            $message = "Buku berhasil diupdate!";
            $message_type = "success";
            $action = 'list';
        } else {
            $message = "Gagal mengupdate buku: " . $conn->error;
            $message_type = "error";
        }
    }
}

// Handle delete
if (isset($_GET['delete']) && $_GET['delete'] > 0) {
    $delete_id = (int)$_GET['delete'];
    $delete_query = "DELETE FROM books WHERE id = ?";
    $stmt = $conn->prepare($delete_query);
    $stmt->bind_param("i", $delete_id);

    if ($stmt->execute()) {
        $message = "Buku berhasil dihapus!";
        $message_type = "success";
    } else {
        $message = "Gagal menghapus buku: " . $conn->error;
        $message_type = "error";
    }
    $action = 'list';
}

// Get book data for edit
$book_data = null;
if ($action == 'edit' && $book_id > 0) {
    $edit_query = "SELECT * FROM books WHERE id = ?";
    $stmt = $conn->prepare($edit_query);
    $stmt->bind_param("i", $book_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $book_data = $result->fetch_assoc();

    if (!$book_data) {
        $message = "Buku tidak ditemukan!";
        $message_type = "error";
        $action = 'list';
    }
}
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Buku - Admin Perpustakaan</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="../style-tailwind.css">
    <!-- SweetAlert2 -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>

<body class="bg-gray-100">
    <div class="flex h-screen">
        <!-- Sidebar -->
        <div class="sidebar-gradient w-64 text-white flex flex-col sticky top-0 h-screen no-print">
            <div class="p-6 border-b border-white border-opacity-20">
                <h3 class="text-xl font-bold">📚 Admin Panel</h3>
            </div>
            <nav class="flex-1 px-4 py-6 space-y-2">
                <a href="dashboard.php"
                    class="flex items-center px-4 py-3 text-white hover:bg-white hover:bg-opacity-10 rounded-lg transition-colors">
                    📊 Dashboard
                </a>
                <a href="books.php"
                    class="flex items-center px-4 py-3 text-white bg-white bg-opacity-20 rounded-lg font-medium">
                    📖 Kelola Buku
                </a>
                <a href="borrowings.php"
                    class="flex items-center px-4 py-3 text-white hover:bg-white hover:bg-opacity-10 rounded-lg transition-colors">
                    📋 Kelola Peminjaman
                </a>
                <a href="users.php"
                    class="flex items-center px-4 py-3 text-white hover:bg-white hover:bg-opacity-10 rounded-lg transition-colors">
                    👥 Kelola User
                </a>
                <a href="../logout.php"
                    class="flex items-center px-4 py-3 text-white hover:bg-white hover:bg-opacity-10 rounded-lg transition-colors">
                    🚪 Logout
                </a>
            </nav>
        </div>

        <!-- Main Content -->
        <div class="flex-1 flex flex-col overflow-hidden">
            <!-- Header -->
            <div class="bg-white shadow-sm border-b border-gray-200 px-6 py-4">
                <div class="flex justify-between items-center">
                    <h1 class="text-2xl font-bold text-gray-900">Kelola Buku</h1>
                    <div class="flex items-center space-x-3">
                        <div
                            class="w-8 h-8 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center text-white font-bold text-sm">
                            <?php echo strtoupper(substr($_SESSION['username'], 0, 1)); ?>
                        </div>
                        <div class="text-sm">
                            <div class="font-medium text-gray-900"><?php echo $_SESSION['username']; ?></div>
                            <div class="text-gray-500">Administrator</div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Content -->
            <div class="flex-1 overflow-auto p-6">
                <?php if (!empty($message)): ?>
                <script>
                document.addEventListener('DOMContentLoaded', function() {
                    Swal.fire({
                        title: '<?php echo $message_type == "success" ? "Berhasil!" : "Error!"; ?>',
                        text: '<?php echo addslashes($message); ?>',
                        icon: '<?php echo $message_type == "success" ? "success" : "error"; ?>',
                        confirmButtonColor: '<?php echo $message_type == "success" ? "#10b981" : "#ef4444"; ?>',
                        confirmButtonText: 'OK'
                    });
                });
                </script>
                <?php endif; ?>

                <?php if ($action == 'list'): ?>
                <div class="flex justify-between items-center mb-6">
                    <h2 class="text-xl font-semibold text-gray-900">Daftar Buku</h2>
                    <a href="?action=add"
                        class="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg font-medium transition-colors flex items-center space-x-2">
                        <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                            <path
                                d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm5 11h-4v4h-2v-4H7v-2h4V7h2v4h4v2z" />
                        </svg>
                        <span>Tambah Buku Baru</span>
                    </a>
                </div>

                <div class="bg-white rounded-lg shadow-sm overflow-hidden">
                    <div class="overflow-x-auto">
                        <table class="min-w-full divide-y divide-gray-200">
                            <thead class="bg-gray-50">
                                <tr>
                                    <th
                                        class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        <div class="flex items-center">
                                            <svg class="w-4 h-4 mr-2" fill="currentColor" viewBox="0 0 24 24">
                                                <path
                                                    d="M3 13h2v-2H3v2zm0 4h2v-2H3v2zm0-8h2V7H3v2zm4 4h14v-2H7v2zm0 4h14v-2H7v2zM7 7v2h14V7H7z" />
                                            </svg>
                                            No.
                                        </div>
                                    </th>
                                    <th
                                        class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        <div class="flex items-center">
                                            <svg class="w-4 h-4 mr-2" fill="currentColor" viewBox="0 0 24 24">
                                                <path
                                                    d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
                                            </svg>
                                            Judul
                                        </div>
                                    </th>
                                    <th
                                        class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        <div class="flex items-center">
                                            <svg class="w-4 h-4 mr-2" fill="currentColor" viewBox="0 0 24 24">
                                                <path
                                                    d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                                            </svg>
                                            Penulis
                                        </div>
                                    </th>
                                    <th
                                        class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        <div class="flex items-center">
                                            <svg class="w-4 h-4 mr-2" fill="currentColor" viewBox="0 0 24 24">
                                                <path
                                                    d="M7 4V2C7 1.45 7.45 1 8 1H16C16.55 1 17 1.45 17 2V4H20C20.55 4 21 4.45 21 5S20.55 6 20 6H19V19C19 20.1 18.1 21 17 21H7C5.9 21 5 20.1 5 19V6H4C3.45 6 3 5.55 3 5S3.45 4 4 4H7ZM9 3V4H15V3H9ZM7 6V19H17V6H7Z" />
                                            </svg>
                                            ISBN
                                        </div>
                                    </th>
                                    <th
                                        class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        <div class="flex items-center">
                                            <svg class="w-4 h-4 mr-2" fill="currentColor" viewBox="0 0 24 24">
                                                <path
                                                    d="M8 7V3a1 1 0 012 0v4h4V3a1 1 0 012 0v4h2a1 1 0 011 1v11a1 1 0 01-1 1H6a1 1 0 01-1-1V8a1 1 0 011-1h2z" />
                                            </svg>
                                            Tahun
                                        </div>
                                    </th>
                                    <th
                                        class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        <div class="flex items-center">
                                            <svg class="w-4 h-4 mr-2" fill="currentColor" viewBox="0 0 24 24">
                                                <path
                                                    d="M7 4V2C7 1.45 7.45 1 8 1H16C16.55 1 17 1.45 17 2V4H20C20.55 4 21 4.45 21 5S20.55 6 20 6H19V19C19 20.1 18.1 21 17 21H7C5.9 21 5 20.1 5 19V6H4C3.45 6 3 5.55 3 5S3.45 4 4 4H7ZM9 3V4H15V3H9ZM7 6V19H17V6H7Z" />
                                            </svg>
                                            Stok
                                        </div>
                                    </th>
                                    <th
                                        class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        <div class="flex items-center">
                                            <svg class="w-4 h-4 mr-2" fill="currentColor" viewBox="0 0 24 24">
                                                <path
                                                    d="M13 3l3.293 3.293c.39.39.39 1.024 0 1.414L12 12l4.293 4.293c.39.39.39 1.024 0 1.414L13 21l-3.293-3.293c-.39-.39-.39-1.024 0-1.414L14 12 9.707 7.707c-.39-.39-.39-1.024 0-1.414L13 3z" />
                                            </svg>
                                            Aksi
                                        </div>
                                    </th>
                                </tr>
                            </thead>
                            <tbody class="bg-white divide-y divide-gray-200">
                                <?php
                                    $books_query = "SELECT * FROM books ORDER BY created_at DESC";
                                    $books_result = $conn->query($books_query);

                                    if ($books_result->num_rows > 0) {
                                        $no = 1;
                                        while ($book = $books_result->fetch_assoc()) {
                                            echo "<tr class='hover:bg-gray-50'>";
                                            echo "<td class='px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900 text-center'>" . $no . "</td>";
                                            echo "<td class='px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900'>" . htmlspecialchars($book['title']) . "</td>";
                                            echo "<td class='px-6 py-4 whitespace-nowrap text-sm text-gray-500'>" . htmlspecialchars($book['author']) . "</td>";
                                            echo "<td class='px-6 py-4 whitespace-nowrap text-sm text-gray-500'>" . htmlspecialchars($book['isbn']) . "</td>";
                                            echo "<td class='px-6 py-4 whitespace-nowrap text-sm text-gray-500'>" . $book['year_published'] . "</td>";
                                            echo "<td class='px-6 py-4 whitespace-nowrap text-sm text-gray-500'>" . $book['stock'] . "</td>";
                                            echo "<td class='px-6 py-4 whitespace-nowrap text-sm font-medium'>";
                                            echo "<div class='flex space-x-2'>";
                                            echo "<a href='?action=edit&id=" . $book['id'] . "' class='bg-yellow-100 hover:bg-yellow-200 text-yellow-600 hover:text-yellow-800 px-3 py-1 rounded-lg flex items-center space-x-1 transition-colors'>";
                                            echo "<svg class='w-4 h-4' fill='currentColor' viewBox='0 0 24 24'><path d='M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04c.39-.39.39-1.02 0-1.41l-2.34-2.34c-.39-.39-1.02-.39-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z'/></svg>";
                                            echo "<span>Edit</span></a>";
                                            echo "<button onclick='confirmDelete(" . $book['id'] . ", \"" . addslashes($book['title']) . "\")' class='bg-red-100 hover:bg-red-200 text-red-600 hover:text-red-800 px-3 py-1 rounded-lg flex items-center space-x-1 transition-colors cursor-pointer'>";
                                            echo "<svg class='w-4 h-4' fill='currentColor' viewBox='0 0 24 24'><path d='M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z'/></svg>";
                                            echo "<span>Hapus</span></button>";
                                            echo "</div>";
                                            echo "</td>";
                                            echo "</tr>";
                                            $no++;
                                        }
                                    } else {
                                        echo "<tr><td colspan='7' class='px-6 py-4 text-center text-sm text-gray-500'>Belum ada buku</td></tr>";
                                    }
                                    ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <?php elseif ($action == 'add'): ?>
                <div class="flex justify-between items-center mb-6">
                    <h2 class="text-xl font-semibold text-gray-900">Tambah Buku Baru</h2>
                    <a href="?action=list"
                        class="bg-gray-600 hover:bg-gray-700 text-white px-4 py-2 rounded-lg font-medium transition-colors">
                        ← Kembali
                    </a>
                </div>

                <div class="bg-white rounded-lg shadow-sm p-6">
                    <form method="POST" action="" class="space-y-6">
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div>
                                <label for="title" class="block text-sm font-medium text-gray-700 mb-2">
                                    Judul Buku
                                </label>
                                <input type="text" id="title" name="title" required
                                    class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500">
                            </div>

                            <div>
                                <label for="author" class="block text-sm font-medium text-gray-700 mb-2">
                                    Penulis
                                </label>
                                <input type="text" id="author" name="author" required
                                    class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500">
                            </div>

                            <div>
                                <label for="isbn" class="block text-sm font-medium text-gray-700 mb-2">
                                    ISBN
                                </label>
                                <input type="text" id="isbn" name="isbn"
                                    class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500">
                            </div>

                            <div>
                                <label for="publisher" class="block text-sm font-medium text-gray-700 mb-2">
                                    Penerbit
                                </label>
                                <input type="text" id="publisher" name="publisher"
                                    class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500">
                            </div>

                            <div>
                                <label for="year_published" class="block text-sm font-medium text-gray-700 mb-2">
                                    Tahun Terbit
                                </label>
                                <input type="number" id="year_published" name="year_published" min="1900"
                                    max="<?php echo date('Y'); ?>"
                                    class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500">
                            </div>

                            <div>
                                <label for="stock" class="block text-sm font-medium text-gray-700 mb-2">
                                    Stok
                                </label>
                                <input type="number" id="stock" name="stock" min="0" value="0" required
                                    class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500">
                            </div>
                        </div>

                        <div>
                            <label for="description" class="block text-sm font-medium text-gray-700 mb-2">
                                Deskripsi
                            </label>
                            <textarea id="description" name="description" rows="4"
                                class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"></textarea>
                        </div>

                        <div class="flex space-x-3">
                            <button type="submit" name="add_book"
                                class="bg-green-600 hover:bg-green-700 text-white px-6 py-2 rounded-lg font-medium transition-colors flex items-center space-x-2">
                                <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                                    <path
                                        d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm5 11h-4v4h-2v-4H7v-2h4V7h2v4h4v2z" />
                                </svg>
                                <span>Tambah Buku</span>
                            </button>
                            <a href="?action=list"
                                class="bg-gray-600 hover:bg-gray-700 text-white px-6 py-2 rounded-lg font-medium transition-colors flex items-center space-x-2">
                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M6 18L18 6M6 6l12 12" />
                                </svg>
                                <span>Batal</span>
                            </a>
                        </div>
                    </form>
                </div>

                <?php elseif ($action == 'edit' && $book_data): ?>
                <div class="flex justify-between items-center mb-6">
                    <h2 class="text-xl font-semibold text-gray-900">Edit Buku</h2>
                    <a href="?action=list"
                        class="bg-gray-600 hover:bg-gray-700 text-white px-4 py-2 rounded-lg font-medium transition-colors">
                        ← Kembali
                    </a>
                </div>

                <div class="bg-white rounded-lg shadow-sm p-6">
                    <form method="POST" action="" class="space-y-6">
                        <input type="hidden" name="id" value="<?php echo $book_data['id']; ?>">

                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div>
                                <label for="title" class="block text-sm font-medium text-gray-700 mb-2">
                                    Judul Buku
                                </label>
                                <input type="text" id="title" name="title"
                                    value="<?php echo htmlspecialchars($book_data['title']); ?>" required
                                    class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500">
                            </div>

                            <div>
                                <label for="author" class="block text-sm font-medium text-gray-700 mb-2">
                                    Penulis
                                </label>
                                <input type="text" id="author" name="author"
                                    value="<?php echo htmlspecialchars($book_data['author']); ?>" required
                                    class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500">
                            </div>

                            <div>
                                <label for="isbn" class="block text-sm font-medium text-gray-700 mb-2">
                                    ISBN
                                </label>
                                <input type="text" id="isbn" name="isbn"
                                    value="<?php echo htmlspecialchars($book_data['isbn']); ?>"
                                    class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500">
                            </div>

                            <div>
                                <label for="publisher" class="block text-sm font-medium text-gray-700 mb-2">
                                    Penerbit
                                </label>
                                <input type="text" id="publisher" name="publisher"
                                    value="<?php echo htmlspecialchars($book_data['publisher']); ?>"
                                    class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500">
                            </div>

                            <div>
                                <label for="year_published" class="block text-sm font-medium text-gray-700 mb-2">
                                    Tahun Terbit
                                </label>
                                <input type="number" id="year_published" name="year_published"
                                    value="<?php echo $book_data['year_published']; ?>" min="1900"
                                    max="<?php echo date('Y'); ?>"
                                    class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500">
                            </div>

                            <div>
                                <label for="stock" class="block text-sm font-medium text-gray-700 mb-2">
                                    Stok
                                </label>
                                <input type="number" id="stock" name="stock" value="<?php echo $book_data['stock']; ?>"
                                    min="0" required
                                    class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500">
                            </div>
                        </div>

                        <div>
                            <label for="description" class="block text-sm font-medium text-gray-700 mb-2">
                                Deskripsi
                            </label>
                            <textarea id="description" name="description" rows="4"
                                class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"><?php echo htmlspecialchars($book_data['description']); ?></textarea>
                        </div>

                        <div class="flex space-x-3">
                            <button type="submit" name="update_book"
                                class="bg-yellow-600 hover:bg-yellow-700 text-white px-6 py-2 rounded-lg font-medium transition-colors flex items-center space-x-2">
                                <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                                    <path
                                        d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04c.39-.39.39-1.02 0-1.41l-2.34-2.34c-.39-.39-1.02-.39-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z" />
                                </svg>
                                <span>Update Buku</span>
                            </button>
                            <a href="?action=list"
                                class="bg-gray-600 hover:bg-gray-700 text-white px-6 py-2 rounded-lg font-medium transition-colors flex items-center space-x-2">
                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M6 18L18 6M6 6l12 12" />
                                </svg>
                                <span>Batal</span>
                            </a>
                        </div>
                    </form>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script>
    // SweetAlert confirmation for delete
    function confirmDelete(bookId, bookTitle) {
        Swal.fire({
            title: 'Konfirmasi Hapus Buku',
            html: `Yakin ingin menghapus buku<br><strong>"${bookTitle}"</strong>?<br><br><small class="text-red-500">⚠️ Aksi ini tidak dapat dibatalkan!</small>`,
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#ef4444',
            cancelButtonColor: '#6b7280',
            confirmButtonText: '🗑️ Ya, Hapus',
            cancelButtonText: '✕ Batal',
            reverseButtons: true
        }).then((result) => {
            if (result.isConfirmed) {
                // Redirect to delete URL
                window.location.href = '?delete=' + bookId;
            }
        });
    }
    </script>
</body>

</html>