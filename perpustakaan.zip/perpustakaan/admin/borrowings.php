<?php
session_start();
require_once '../config.php';

// Cek apakah user adalah admin
check_admin();

// Update status overdue
update_overdue_books($conn);

$message = '';
$message_type = '';

// Handle force return (admin dapat memaksa pengembalian)
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['force_return'])) {
    $borrowing_id = (int)$_POST['borrowing_id'];
    $result = return_book_with_fine($conn, $borrowing_id);

    $message = $result['message'];
    $message_type = $result['success'] ? 'success' : 'error';
}

// Handle pay fine
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['pay_fine'])) {
    $borrowing_id = (int)$_POST['borrowing_id'];
    $result = pay_fine($conn, $borrowing_id);

    $message = $result['message'];
    $message_type = $result['success'] ? 'success' : 'error';
}

// Handle extend due date
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['extend_due'])) {
    $borrowing_id = (int)$_POST['borrowing_id'];
    $new_due_date = clean_input($_POST['new_due_date']);

    $update_due = "UPDATE borrowings SET due_date = ?, status = 'borrowed' WHERE id = ? AND status IN ('borrowed', 'overdue')";
    $stmt = $conn->prepare($update_due);
    $stmt->bind_param("si", $new_due_date, $borrowing_id);

    if ($stmt->execute()) {
        $message = "Tanggal jatuh tempo berhasil diperpanjang!";
        $message_type = "success";
    } else {
        $message = "Gagal memperpanjang tanggal jatuh tempo!";
        $message_type = "error";
    }
}

// Filter
$filter = isset($_GET['filter']) ? $_GET['filter'] : 'all';
$search = isset($_GET['search']) ? clean_input($_GET['search']) : '';

// Query peminjaman
$borrowings_query = "SELECT b.*, u.username, u.email, bk.title, bk.author, bk.isbn 
                     FROM borrowings b 
                     JOIN users u ON b.user_id = u.id 
                     JOIN books bk ON b.book_id = bk.id";

$where_conditions = [];
if ($filter == 'has_fines') {
    $where_conditions[] = "b.fine_amount > 0";
} elseif ($filter != 'all') {
    $where_conditions[] = "b.status = '$filter'";
}
if (!empty($search)) {
    $where_conditions[] = "(bk.title LIKE '%$search%' OR bk.author LIKE '%$search%' OR u.username LIKE '%$search%')";
}

if (!empty($where_conditions)) {
    $borrowings_query .= " WHERE " . implode(" AND ", $where_conditions);
}

$borrowings_query .= " ORDER BY b.created_at DESC";
$borrowings_result = $conn->query($borrowings_query);

// Statistik peminjaman
$stats_query = "SELECT 
                    COUNT(*) as total_borrowings,
                    SUM(CASE WHEN status = 'borrowed' THEN 1 ELSE 0 END) as currently_borrowed,
                    SUM(CASE WHEN status = 'returned' THEN 1 ELSE 0 END) as returned,
                    SUM(CASE WHEN status = 'overdue' THEN 1 ELSE 0 END) as overdue,
                    SUM(CASE WHEN fine_amount > 0 AND fine_paid = 0 THEN fine_amount ELSE 0 END) as unpaid_fines,
                    SUM(CASE WHEN fine_amount > 0 AND fine_paid = 1 THEN fine_amount ELSE 0 END) as paid_fines
                FROM borrowings";
$stats_result = $conn->query($stats_query);
$stats = $stats_result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Peminjaman - Admin Perpustakaan</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="../style-tailwind.css">
    <!-- SweetAlert2 -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>

<body class="bg-gray-100">
    <div class="flex h-screen">
        <!-- Sidebar -->
        <div class="sidebar-gradient w-64 text-white flex flex-col sticky top-0 h-screen no-print">
            <div class="p-6 border-b border-white border-opacity-20">
                <h3 class="text-xl font-bold">📚 Admin Panel</h3>
            </div>
            <nav class="flex-1 px-4 py-6 space-y-2">
                <a href="dashboard.php"
                    class="flex items-center px-4 py-3 text-white hover:bg-white hover:bg-opacity-10 rounded-lg transition-colors">
                    📊 Dashboard
                </a>
                <a href="books.php"
                    class="flex items-center px-4 py-3 text-white hover:bg-white hover:bg-opacity-10 rounded-lg transition-colors">
                    📖 Kelola Buku
                </a>
                <a href="borrowings.php"
                    class="flex items-center px-4 py-3 text-white bg-white bg-opacity-20 rounded-lg font-medium">
                    📋 Kelola Peminjaman
                </a>
                <a href="users.php"
                    class="flex items-center px-4 py-3 text-white hover:bg-white hover:bg-opacity-10 rounded-lg transition-colors">
                    👥 Kelola User
                </a>
                <a href="../logout.php"
                    class="flex items-center px-4 py-3 text-white hover:bg-white hover:bg-opacity-10 rounded-lg transition-colors">
                    🚪 Logout
                </a>
            </nav>
        </div>

        <!-- Main Content -->
        <div class="flex-1 flex flex-col overflow-hidden">
            <!-- Header -->
            <div class="bg-white shadow-sm border-b border-gray-200 px-6 py-4">
                <div class="flex justify-between items-center">
                    <h1 class="text-2xl font-bold text-gray-900">Kelola Peminjaman</h1>
                    <div class="flex items-center space-x-3">
                        <div
                            class="w-8 h-8 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center text-white font-bold text-sm">
                            <?php echo strtoupper(substr($_SESSION['username'], 0, 1)); ?>
                        </div>
                        <div class="text-sm">
                            <div class="font-medium text-gray-900"><?php echo $_SESSION['username']; ?></div>
                            <div class="text-gray-500">Administrator</div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Content -->
            <div class="flex-1 overflow-auto p-6">
                <?php if (!empty($message)): ?>
                <script>
                document.addEventListener('DOMContentLoaded', function() {
                    Swal.fire({
                        title: '<?php echo $message_type == "success" ? "Berhasil!" : "Error!"; ?>',
                        text: '<?php echo addslashes($message); ?>',
                        icon: '<?php echo $message_type == "success" ? "success" : "error"; ?>',
                        confirmButtonColor: '<?php echo $message_type == "success" ? "#10b981" : "#ef4444"; ?>',
                        confirmButtonText: 'OK'
                    });
                });
                </script>
                <?php endif; ?>

                <!-- Statistics Grid -->
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-6">
                    <div class="bg-white rounded-lg shadow-sm p-6">
                        <div class="flex items-center">
                            <div class="p-2 bg-blue-100 rounded-lg">
                                <svg class="w-6 h-6 text-blue-600" fill="none" stroke="currentColor"
                                    viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z">
                                    </path>
                                </svg>
                            </div>
                            <div class="ml-4">
                                <p class="text-sm font-medium text-gray-600">Total Peminjaman</p>
                                <p class="text-2xl font-bold text-gray-900"><?php echo $stats['total_borrowings']; ?>
                                </p>
                            </div>
                        </div>
                    </div>

                    <div class="bg-white rounded-lg shadow-sm p-6">
                        <div class="flex items-center">
                            <div class="p-2 bg-yellow-100 rounded-lg">
                                <svg class="w-6 h-6 text-yellow-600" fill="none" stroke="currentColor"
                                    viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                </svg>
                            </div>
                            <div class="ml-4">
                                <p class="text-sm font-medium text-gray-600">Sedang Dipinjam</p>
                                <p class="text-2xl font-bold text-gray-900"><?php echo $stats['currently_borrowed']; ?>
                                </p>
                            </div>
                        </div>
                    </div>

                    <div class="bg-white rounded-lg shadow-sm p-6">
                        <div class="flex items-center">
                            <div class="p-2 bg-green-100 rounded-lg">
                                <svg class="w-6 h-6 text-green-600" fill="none" stroke="currentColor"
                                    viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M5 13l4 4L19 7"></path>
                                </svg>
                            </div>
                            <div class="ml-4">
                                <p class="text-sm font-medium text-gray-600">Sudah Dikembalikan</p>
                                <p class="text-2xl font-bold text-gray-900"><?php echo $stats['returned']; ?></p>
                            </div>
                        </div>
                    </div>

                    <div class="bg-white rounded-lg shadow-sm p-6">
                        <div class="flex items-center">
                            <div class="p-2 bg-red-100 rounded-lg">
                                <svg class="w-6 h-6 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L3.732 16.5c-.77.833.192 2.5 1.732 2.5z">
                                    </path>
                                </svg>
                            </div>
                            <div class="ml-4">
                                <p class="text-sm font-medium text-gray-600">Terlambat</p>
                                <p class="text-2xl font-bold text-gray-900"><?php echo $stats['overdue']; ?></p>
                            </div>
                        </div>
                    </div>

                    <div class="bg-white rounded-lg shadow-sm p-6">
                        <div class="flex items-center">
                            <div class="p-2 bg-orange-100 rounded-lg">
                                <svg class="w-6 h-6 text-orange-600" fill="none" stroke="currentColor"
                                    viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1">
                                    </path>
                                </svg>
                            </div>
                            <div class="ml-4">
                                <p class="text-sm font-medium text-gray-600">Denda Belum Bayar</p>
                                <p class="text-2xl font-bold text-gray-900">Rp
                                    <?php echo number_format($stats['unpaid_fines'], 0, ',', '.'); ?></p>
                            </div>
                        </div>
                    </div>

                    <div class="bg-white rounded-lg shadow-sm p-6">
                        <div class="flex items-center">
                            <div class="p-2 bg-purple-100 rounded-lg">
                                <svg class="w-6 h-6 text-purple-600" fill="none" stroke="currentColor"
                                    viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M9 12l2 2 4-4M7.835 4.697a3.42 3.42 0 001.946-.806 3.42 3.42 0 014.438 0 3.42 3.42 0 001.946.806 3.42 3.42 0 013.138 3.138 3.42 3.42 0 00.806 1.946 3.42 3.42 0 010 4.438 3.42 3.42 0 00-.806 1.946 3.42 3.42 0 01-3.138 3.138 3.42 3.42 0 00-1.946.806 3.42 3.42 0 01-4.438 0 3.42 3.42 0 00-1.946-.806 3.42 3.42 0 01-3.138-3.138 3.42 3.42 0 00-.806-1.946 3.42 3.42 0 010-4.438 3.42 3.42 0 00.806-1.946 3.42 3.42 0 013.138-3.138z">
                                    </path>
                                </svg>
                            </div>
                            <div class="ml-4">
                                <p class="text-sm font-medium text-gray-600">Denda Sudah Bayar</p>
                                <p class="text-2xl font-bold text-gray-900">Rp
                                    <?php echo number_format($stats['paid_fines'], 0, ',', '.'); ?></p>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Filter Section -->
                <div class="bg-white rounded-lg shadow-sm p-6 mb-6">
                    <div class="flex items-center mb-4">
                        <svg class="w-6 h-6 text-gray-700 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="M3 4a1 1 0 011-1h16a1 1 0 011 1v2.586a1 1 0 01-.293.707l-6.414 6.414a1 1 0 00-.293.707V17l-4 4v-6.586a1 1 0 00-.293-.707L3.293 7.414A1 1 0 013 6.707V4z" />
                        </svg>
                        <h3 class="text-lg font-medium text-gray-900">Filter & Pencarian</h3>
                    </div>
                    <form method="GET" action="" class="flex flex-col md:flex-row gap-4">
                        <div class="relative">
                            <svg class="w-5 h-5 text-gray-400 absolute left-3 top-1/2 transform -translate-y-1/2"
                                fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M3 4a1 1 0 011-1h16a1 1 0 011 1v2.586a1 1 0 01-.293.707l-6.414 6.414a1 1 0 00-.293.707V17l-4 4v-6.586a1 1 0 00-.293-.707L3.293 7.414A1 1 0 013 6.707V4z" />
                            </svg>
                            <select name="filter" onchange="this.form.submit()"
                                class="pl-10 pr-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500">
                                <option value="all" <?php echo $filter == 'all' ? 'selected' : ''; ?>>Semua Status
                                </option>
                                <option value="borrowed" <?php echo $filter == 'borrowed' ? 'selected' : ''; ?>>Sedang
                                    Dipinjam</option>
                                <option value="overdue" <?php echo $filter == 'overdue' ? 'selected' : ''; ?>>Terlambat
                                </option>
                                <option value="returned" <?php echo $filter == 'returned' ? 'selected' : ''; ?>>Sudah
                                    Dikembalikan</option>
                                <option value="has_fines" <?php echo $filter == 'has_fines' ? 'selected' : ''; ?>>Ada
                                    Denda
                                </option>
                            </select>
                        </div>

                        <div class="relative flex-1">
                            <svg class="w-5 h-5 text-gray-400 absolute left-3 top-1/2 transform -translate-y-1/2"
                                fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                            </svg>
                            <input type="text" name="search" placeholder="Cari buku, penulis, atau username..."
                                value="<?php echo htmlspecialchars($search); ?>"
                                class="pl-10 pr-3 py-2 w-full border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500">
                        </div>

                        <button type="submit"
                            class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-md font-medium transition-colors flex items-center space-x-2">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                            </svg>
                            <span>Cari</span>
                        </button>

                        <?php if (!empty($search) || $filter != 'all'): ?>
                        <a href="borrowings.php"
                            class="bg-gray-600 hover:bg-gray-700 text-white px-4 py-2 rounded-md font-medium transition-colors flex items-center space-x-2">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                            </svg>
                            <span>Reset</span>
                        </a>
                        <?php endif; ?>
                    </form>
                </div>

                <!-- Borrowings Table -->
                <div class="bg-white rounded-lg shadow-sm overflow-hidden">
                    <div class="overflow-x-auto">
                        <table class="min-w-full divide-y divide-gray-200">
                            <thead class="bg-gray-50">
                                <tr>
                                    <th
                                        class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        <div class="flex items-center">
                                            <svg class="w-4 h-4 mr-2" fill="currentColor" viewBox="0 0 24 24">
                                                <path
                                                    d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                                            </svg>
                                            User
                                        </div>
                                    </th>
                                    <th
                                        class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        <div class="flex items-center">
                                            <svg class="w-4 h-4 mr-2" fill="currentColor" viewBox="0 0 24 24">
                                                <path
                                                    d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
                                            </svg>
                                            Buku
                                        </div>
                                    </th>
                                    <th
                                        class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        <div class="flex items-center">
                                            <svg class="w-4 h-4 mr-2" fill="currentColor" viewBox="0 0 24 24">
                                                <path
                                                    d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                                            </svg>
                                            Penulis
                                        </div>
                                    </th>
                                    <th
                                        class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        <div class="flex items-center">
                                            <svg class="w-4 h-4 mr-2" fill="currentColor" viewBox="0 0 24 24">
                                                <path
                                                    d="M8 7V3a1 1 0 012 0v4h4V3a1 1 0 012 0v4h2a1 1 0 011 1v11a1 1 0 01-1 1H6a1 1 0 01-1-1V8a1 1 0 011-1h2z" />
                                            </svg>
                                            Tgl Pinjam
                                        </div>
                                    </th>
                                    <th
                                        class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        <div class="flex items-center">
                                            <svg class="w-4 h-4 mr-2" fill="currentColor" viewBox="0 0 24 24">
                                                <path d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                                            </svg>
                                            Jatuh Tempo
                                        </div>
                                    </th>
                                    <th
                                        class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        <div class="flex items-center">
                                            <svg class="w-4 h-4 mr-2" fill="currentColor" viewBox="0 0 24 24">
                                                <path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                                            </svg>
                                            Tgl Kembali
                                        </div>
                                    </th>
                                    <th
                                        class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        <div class="flex items-center">
                                            <svg class="w-4 h-4 mr-2" fill="currentColor" viewBox="0 0 24 24">
                                                <path
                                                    d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1" />
                                            </svg>
                                            Denda
                                        </div>
                                    </th>
                                    <th
                                        class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        <div class="flex items-center">
                                            <svg class="w-4 h-4 mr-2" fill="currentColor" viewBox="0 0 24 24">
                                                <path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                                            </svg>
                                            Status
                                        </div>
                                    </th>
                                    <th
                                        class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        <div class="flex items-center">
                                            <svg class="w-4 h-4 mr-2" fill="currentColor" viewBox="0 0 24 24">
                                                <path
                                                    d="M13 3l3.293 3.293c.39.39.39 1.024 0 1.414L12 12l4.293 4.293c.39.39.39 1.024 0 1.414L13 21l-3.293-3.293c-.39-.39-.39-1.024 0-1.414L14 12 9.707 7.707c-.39-.39-.39-1.024 0-1.414L13 3z" />
                                            </svg>
                                            Aksi
                                        </div>
                                    </th>
                                </tr>
                            </thead>
                            <tbody class="bg-white divide-y divide-gray-200">
                                <?php if ($borrowings_result->num_rows > 0): ?>
                                <?php while ($borrowing = $borrowings_result->fetch_assoc()): ?>
                                <tr class="hover:bg-gray-50 ">
                                    <td class="px-6 py-4 whitespace-nowrap text-sm">
                                        <div class="font-medium text-gray-900">
                                            <?php echo htmlspecialchars($borrowing['username']); ?></div>
                                        <div class="text-gray-500"><?php echo htmlspecialchars($borrowing['email']); ?>
                                        </div>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                                        <?php echo htmlspecialchars($borrowing['title']); ?></td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                        <?php echo htmlspecialchars($borrowing['author']); ?></td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                        <?php echo date('d/m/Y', strtotime($borrowing['borrow_date'])); ?></td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm">
                                        <?php
                                                $due_date = date('d/m/Y', strtotime($borrowing['due_date']));
                                                $is_overdue = ($borrowing['status'] == 'overdue' ||
                                                    ($borrowing['status'] == 'borrowed' && strtotime($borrowing['due_date']) < time()));
                                                if ($is_overdue && $borrowing['status'] != 'returned') {
                                                    echo "<span class='text-red-600 font-bold'>" . $due_date . "</span>";
                                                } else {
                                                    echo "<span class='text-gray-500'>" . $due_date . "</span>";
                                                }
                                                ?>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                        <?php
                                                if ($borrowing['return_date']) {
                                                    echo date('d/m/Y', strtotime($borrowing['return_date']));
                                                } else {
                                                    echo '-';
                                                }
                                                ?>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm">
                                        <?php
                                                $current_fine = 0;
                                                if ($borrowing['status'] == 'overdue' || ($borrowing['status'] == 'returned' && $borrowing['fine_amount'] > 0)) {
                                                    $current_fine = $borrowing['fine_amount'] > 0 ? $borrowing['fine_amount'] : calculate_fine($borrowing['due_date']);
                                                }

                                                if ($current_fine > 0): ?>
                                        <div class="flex flex-col">
                                            <span class="text-red-600 font-bold">Rp
                                                <?php echo number_format($current_fine, 0, ',', '.'); ?></span>
                                            <?php if ($borrowing['fine_paid'] == 1): ?>
                                            <span class="text-xs text-green-600">✓ Sudah Bayar</span>
                                            <?php elseif ($borrowing['status'] == 'returned'): ?>
                                            <span class="text-xs text-red-600">⚠ Belum Bayar</span>
                                            <?php else: ?>
                                            <span class="text-xs text-orange-600">• Masih Berjalan</span>
                                            <?php endif; ?>
                                        </div>
                                        <?php else: ?>
                                        <span class="text-gray-400">-</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <?php
                                                $status_class = '';
                                                $status_text = '';
                                                $status_icon = '';
                                                switch ($borrowing['status']) {
                                                    case 'borrowed':
                                                        $status_class = 'bg-blue-100 text-blue-800';
                                                        $status_text = 'Dipinjam';
                                                        $status_icon = '<svg class="w-4 h-4 mr-1" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>';
                                                        break;
                                                    case 'returned':
                                                        $status_class = 'bg-green-100 text-green-800';
                                                        $status_text = 'Dikembalikan';
                                                        $status_icon = '<svg class="w-4 h-4 mr-1" fill="currentColor" viewBox="0 0 24 24"><path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>';
                                                        break;
                                                    case 'overdue':
                                                        $status_class = 'bg-red-100 text-red-800';
                                                        $status_text = 'Terlambat';
                                                        $status_icon = '<svg class="w-4 h-4 mr-1" fill="currentColor" viewBox="0 0 24 24"><path d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L3.732 16.5c-.77.833.192 2.5 1.732 2.5z"/></svg>';
                                                        break;
                                                }
                                                ?>
                                        <span
                                            class="inline-flex items-center px-2 py-1 text-xs font-semibold rounded-full <?php echo $status_class; ?>"><?php echo $status_icon . $status_text; ?></span>
                                    </td>
                                    <td class="px-6 py-4 text-sm font-medium">
                                        <?php if ($borrowing['status'] == 'borrowed' || $borrowing['status'] == 'overdue'): ?>
                                        <div class="flex space-y-2 flex-col gap-2">
                                            <!-- Force Return Button -->
                                            <form method="POST" class="inline"
                                                id="force-return-form-<?php echo $borrowing['id']; ?>">
                                                <input type="hidden" name="borrowing_id"
                                                    value="<?php echo $borrowing['id']; ?>">
                                                <button type="button" name="force_return"
                                                    class="bg-green-100 hover:bg-green-200 text-green-600 hover:text-green-800 px-3 py-2 rounded-lg flex items-center space-x-1 transition-colors"
                                                    onclick="confirmForceReturn(<?php echo $borrowing['id']; ?>)">
                                                    <svg class="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                                                        <path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                                                    </svg>
                                                    <span>Kembalikan</span>
                                                </button>
                                            </form>

                                            <!-- Extend Due Date Button -->
                                            <button type="button"
                                                class="bg-yellow-100 hover:bg-yellow-200 text-yellow-600 hover:text-yellow-800 px-3 py-2 rounded-lg flex items-center space-x-1 transition-colors"
                                                onclick="showExtendModal(<?php echo $borrowing['id']; ?>, '<?php echo $borrowing['due_date']; ?>')">
                                                <svg class="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                                                    <path d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                                                </svg>
                                                <span>Perpanjang</span>
                                            </button>
                                        </div>
                                        <?php elseif ($borrowing['status'] == 'returned' && $borrowing['fine_amount'] > 0 && $borrowing['fine_paid'] == 0): ?>
                                        <!-- Pay Fine Button -->
                                        <form method="POST" class="inline"
                                            id="pay-fine-form-<?php echo $borrowing['id']; ?>">
                                            <input type="hidden" name="borrowing_id"
                                                value="<?php echo $borrowing['id']; ?>">
                                            <button type="button" name="pay_fine"
                                                class="bg-blue-100 hover:bg-blue-200 text-blue-600 hover:text-blue-800 px-3 py-2 rounded-lg flex items-center space-x-1 transition-colors"
                                                onclick="confirmPayFine(<?php echo $borrowing['id']; ?>, <?php echo $borrowing['fine_amount']; ?>)">
                                                <svg class="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                                                    <path
                                                        d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1" />
                                                </svg>
                                                <span>Bayar Denda</span>
                                            </button>
                                        </form>
                                        <?php else: ?>
                                        <span class="text-gray-400 flex items-center">
                                            <svg class="w-4 h-4 mr-1" fill="currentColor" viewBox="0 0 24 24">
                                                <path
                                                    d="M18.364 5.636l-3.536 3.536m0 5.656l3.536 3.536M9.172 9.172L5.636 5.636m3.536 9.192l-3.536 3.536" />
                                            </svg>
                                            -
                                        </span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                                <?php else: ?>
                                <tr>
                                    <td colspan="10" class="px-6 py-4 text-center text-sm text-gray-500">
                                        <?php if (!empty($search) || $filter != 'all'): ?>
                                        Tidak ada peminjaman yang sesuai dengan filter
                                        <?php else: ?>
                                        Belum ada riwayat peminjaman
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal untuk memperpanjang tanggal jatuh tempo -->
    <div id="extendModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full hidden">
        <div class="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
            <div class="mt-3">
                <div class="flex justify-between items-center mb-4">
                    <div class="flex items-center">
                        <svg class="w-6 h-6 text-yellow-600 mr-3" fill="currentColor" viewBox="0 0 24 24">
                            <path d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                        <h3 class="text-lg font-medium text-gray-900">Perpanjang Tanggal Jatuh Tempo</h3>
                    </div>
                    <button onclick="closeExtendModal()" class="text-gray-400 hover:text-gray-600">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="M6 18L18 6M6 6l12 12"></path>
                        </svg>
                    </button>
                </div>
                <form method="POST" action="">
                    <input type="hidden" id="extend_borrowing_id" name="borrowing_id">
                    <div class="mb-4">
                        <label for="new_due_date" class="block text-sm font-medium text-gray-700 mb-2">
                            Tanggal Jatuh Tempo Baru:
                        </label>
                        <input type="date" id="new_due_date" name="new_due_date" required
                            class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500">
                    </div>
                    <div class="flex space-x-3">
                        <button type="submit" name="extend_due"
                            class="bg-yellow-600 hover:bg-yellow-700 text-white px-4 py-2 rounded-md font-medium transition-colors flex items-center space-x-2">
                            <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                                <path d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                            </svg>
                            <span>Perpanjang</span>
                        </button>
                        <button type="button" onclick="closeExtendModal()"
                            class="bg-gray-600 hover:bg-gray-700 text-white px-4 py-2 rounded-md font-medium transition-colors flex items-center space-x-2">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M6 18L18 6M6 6l12 12" />
                            </svg>
                            <span>Batal</span>
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
    function showExtendModal(borrowingId, currentDueDate) {
        document.getElementById('extend_borrowing_id').value = borrowingId;
        document.getElementById('new_due_date').value = currentDueDate;
        document.getElementById('extendModal').classList.remove('hidden');
    }

    function closeExtendModal() {
        document.getElementById('extendModal').classList.add('hidden');
    }

    // Close modal when clicking outside
    window.onclick = function(event) {
        var modal = document.getElementById('extendModal');
        if (event.target == modal) {
            modal.classList.add('hidden');
        }
    }

    // SweetAlert confirmation for force return
    function confirmForceReturn(borrowingId) {
        Swal.fire({
            title: 'Konfirmasi Pengembalian',
            text: 'Yakin ingin memaksa pengembalian buku ini?',
            icon: 'question',
            showCancelButton: true,
            confirmButtonColor: '#10b981',
            cancelButtonColor: '#6b7280',
            confirmButtonText: '✓ Ya, Kembalikan',
            cancelButtonText: '✕ Batal',
            reverseButtons: true
        }).then((result) => {
            if (result.isConfirmed) {
                // Add the submit name to the form
                const form = document.getElementById('force-return-form-' + borrowingId);
                const submitInput = document.createElement('input');
                submitInput.type = 'hidden';
                submitInput.name = 'force_return';
                submitInput.value = '1';
                form.appendChild(submitInput);

                // Submit the form
                form.submit();
            }
        });
    }

    // SweetAlert confirmation for pay fine
    function confirmPayFine(borrowingId, fineAmount) {
        const formattedAmount = new Intl.NumberFormat('id-ID', {
            style: 'currency',
            currency: 'IDR',
            minimumFractionDigits: 0
        }).format(fineAmount);

        Swal.fire({
            title: 'Konfirmasi Pembayaran Denda',
            html: `Konfirmasi pembayaran denda sebesar<br><strong>${formattedAmount}</strong>?`,
            icon: 'info',
            showCancelButton: true,
            confirmButtonColor: '#3b82f6',
            cancelButtonColor: '#6b7280',
            confirmButtonText: '💳 Ya, Bayar',
            cancelButtonText: '✕ Batal',
            reverseButtons: true
        }).then((result) => {
            if (result.isConfirmed) {
                // Add the submit name to the form
                const form = document.getElementById('pay-fine-form-' + borrowingId);
                const submitInput = document.createElement('input');
                submitInput.type = 'hidden';
                submitInput.name = 'pay_fine';
                submitInput.value = '1';
                form.appendChild(submitInput);

                // Submit the form
                form.submit();
            }
        });
    }
    </script>
</body>

</html>