<?php
session_start();
require_once '../config.php';

// Cek apakah user adalah admin
check_admin();

// Update status overdue
update_overdue_books($conn);

// Ambil statistik
$stats_query = "SELECT 
                    (SELECT COUNT(*) FROM users WHERE role = 'user') as total_users,
                    (SELECT COUNT(*) FROM users WHERE role = 'admin') as total_admins,
                    (SELECT COUNT(*) FROM books) as total_books,
                    (SELECT SUM(stock) FROM books) as total_stock,
                    (SELECT COUNT(*) FROM borrowings WHERE status = 'borrowed') as currently_borrowed,
                    (SELECT COUNT(*) FROM borrowings WHERE status = 'overdue') as overdue_books";
$stats_result = $conn->query($stats_query);
$stats = $stats_result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Admin - Perpustakaan</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="../style-tailwind.css">
    <script>
    tailwind.config = {
        theme: {
            extend: {
                colors: {
                    primary: '#3B82F6',
                    secondary: '#64748B',
                    accent: '#667eea'
                }
            }
        }
    }

    // Print Report Function
    function printReport() {
        window.print();
    }
    </script>
    <style>
    @media print {
        .no-print {
            display: none !important;
        }

        body {
            background: white !important;
        }

        .sidebar-gradient {
            display: none !important;
        }

        .print-header {
            display: block !important;
            text-align: center;
            margin-bottom: 30px;
        }

        .print-date {
            display: block !important;
            text-align: right;
            margin-bottom: 20px;
            font-size: 12px;
        }

        .stat-card {
            background: white !important;
            border: 1px solid #ddd !important;
            color: black !important;
        }

        .bg-white {
            box-shadow: none !important;
        }

        table {
            border-collapse: collapse;
            width: 100%;
        }

        table,
        th,
        td {
            border: 1px solid #ddd;
        }

        th,
        td {
            padding: 8px;
            text-align: left;
        }

        .print-signature {
            display: block !important;
            margin-top: 50px;
            text-align: right;
        }
    }

    .print-header,
    .print-date,
    .print-signature {
        display: none;
    }
    </style>
</head>

<body class="bg-gray-100 font-sans">
    <div class="flex min-h-screen">
        <!-- Sidebar -->
        <div class="sidebar-gradient w-64 text-white flex flex-col sticky top-0 h-screen no-print">
            <div class="p-6 border-b border-white border-opacity-20">
                <h3 class="text-xl font-bold">📚 Admin Panel</h3>
            </div>
            <nav class="flex-1 px-4 py-6 space-y-2">
                <a href="dashboard.php"
                    class="flex items-center px-4 py-3 text-white bg-white bg-opacity-20 rounded-lg font-medium">
                    📊 Dashboard
                </a>
                <a href="books.php"
                    class="flex items-center px-4 py-3 text-white hover:bg-white hover:bg-opacity-10 rounded-lg transition-colors">
                    📖 Kelola Buku
                </a>
                <a href="borrowings.php"
                    class="flex items-center px-4 py-3 text-white hover:bg-white hover:bg-opacity-10 rounded-lg transition-colors">
                    📋 Kelola Peminjaman
                </a>
                <a href="users.php"
                    class="flex items-center px-4 py-3 text-white hover:bg-white hover:bg-opacity-10 rounded-lg transition-colors">
                    👥 Kelola User
                </a>
                <a href="../logout.php"
                    class="flex items-center px-4 py-3 text-white hover:bg-white hover:bg-opacity-10 rounded-lg transition-colors">
                    🚪 Logout
                </a>
            </nav>
        </div>

        <!-- Main Content -->
        <div class="flex-1 ">
            <!-- Header -->
            <header class="bg-white shadow-sm border-b border-gray-200 px-6 py-4 no-print">
                <div class="flex justify-between items-center">
                    <h1 class="text-2xl font-bold text-gray-800">Dashboard Admin</h1>
                    <div class="flex items-center space-x-4">
                        <button onclick="printReport()"
                            class="bg-purple-600 hover:bg-purple-700 text-white px-4 py-2 rounded-lg font-medium transition-colors flex items-center space-x-2">
                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z">
                                </path>
                            </svg>
                            <span>Print Laporan</span>
                        </button>
                        <div
                            class="w-10 h-10 gradient-bg rounded-full flex items-center justify-center text-white font-bold">
                            <?php echo strtoupper(substr($_SESSION['username'], 0, 1)); ?>
                        </div>
                        <div class="text-right">
                            <div class="font-semibold text-gray-800"><?php echo $_SESSION['username']; ?></div>
                            <div class="text-xs text-gray-500 uppercase">Administrator</div>
                        </div>
                    </div>
                </div>
            </header>

            <!-- Print Header (only visible when printing) -->
            <div class="print-header">
                <h1 class="text-3xl font-bold text-gray-800">LAPORAN PERPUSTAKAAN</h1>
                <h2 class="text-xl text-gray-600 mt-2">Dashboard Administrator</h2>
            </div>

            <!-- Print Date (only visible when printing) -->
            <div class="print-date">
                <p>Tanggal Cetak: <?php echo date('d/m/Y H:i:s'); ?></p>
                <p>Dicetak oleh: <?php echo $_SESSION['username']; ?></p>
            </div>

            <!-- Content -->
            <main class="p-6">
                <!-- Stats Grid -->
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
                    <div class="stat-card text-white p-6 rounded-lg shadow-lg">
                        <div class="flex items-center justify-between">
                            <div>
                                <h3 class="text-lg font-semibold mb-2">Total User</h3>
                                <div class="text-3xl font-bold"><?php echo $stats['total_users']; ?></div>
                            </div>
                            <div class="text-4xl opacity-80">
                                <svg class="w-12 h-12" fill="currentColor" viewBox="0 0 24 24">
                                    <path d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                                </svg>
                            </div>
                        </div>
                    </div>

                    <div class="stat-card text-white p-6 rounded-lg shadow-lg">
                        <div class="flex items-center justify-between">
                            <div>
                                <h3 class="text-lg font-semibold mb-2">Total Admin</h3>
                                <div class="text-3xl font-bold"><?php echo $stats['total_admins']; ?></div>
                            </div>
                            <div class="text-4xl opacity-80">
                                <svg class="w-12 h-12" fill="currentColor" viewBox="0 0 24 24">
                                    <path
                                        d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197m3 4.197a4 4 0 11-8 0 4 4 0 018 0z" />
                                </svg>
                            </div>
                        </div>
                    </div>

                    <div class="stat-card text-white p-6 rounded-lg shadow-lg">
                        <div class="flex items-center justify-between">
                            <div>
                                <h3 class="text-lg font-semibold mb-2">Total Buku</h3>
                                <div class="text-3xl font-bold"><?php echo $stats['total_books']; ?></div>
                            </div>
                            <div class="text-4xl opacity-80">
                                <svg class="w-12 h-12" fill="currentColor" viewBox="0 0 24 24">
                                    <path
                                        d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
                                </svg>
                            </div>
                        </div>
                    </div>

                    <div class="stat-card text-white p-6 rounded-lg shadow-lg">
                        <div class="flex items-center justify-between">
                            <div>
                                <h3 class="text-lg font-semibold mb-2">Total Stok</h3>
                                <div class="text-3xl font-bold"><?php echo $stats['total_stock']; ?></div>
                            </div>
                            <div class="text-4xl opacity-80">
                                <svg class="w-12 h-12" fill="currentColor" viewBox="0 0 24 24">
                                    <path
                                        d="M7 4V2C7 1.45 7.45 1 8 1H16C16.55 1 17 1.45 17 2V4H20C20.55 4 21 4.45 21 5S20.55 6 20 6H19V19C19 20.1 18.1 21 17 21H7C5.9 21 5 20.1 5 19V6H4C3.45 6 3 5.55 3 5S3.45 4 4 4H7ZM9 3V4H15V3H9ZM7 6V19H17V6H7Z" />
                                </svg>
                            </div>
                        </div>
                    </div>

                    <div class="stat-card text-white p-6 rounded-lg shadow-lg">
                        <div class="flex items-center justify-between">
                            <div>
                                <h3 class="text-lg font-semibold mb-2">Sedang Dipinjam</h3>
                                <div class="text-3xl font-bold"><?php echo $stats['currently_borrowed']; ?></div>
                            </div>
                            <div class="text-4xl opacity-80">
                                <svg class="w-12 h-12" fill="currentColor" viewBox="0 0 24 24">
                                    <path
                                        d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" />
                                </svg>
                            </div>
                        </div>
                    </div>

                    <div class="stat-card text-white p-6 rounded-lg shadow-lg">
                        <div class="flex items-center justify-between">
                            <div>
                                <h3 class="text-lg font-semibold mb-2">Buku Terlambat</h3>
                                <div class="text-3xl font-bold"><?php echo $stats['overdue_books']; ?></div>
                            </div>
                            <div class="text-4xl opacity-80">
                                <svg class="w-12 h-12" fill="currentColor" viewBox="0 0 24 24">
                                    <path
                                        d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z" />
                                </svg>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Recent Books -->
                <div class="bg-white rounded-lg shadow-sm p-6">
                    <div class="flex items-center mb-4">
                        <svg class="w-6 h-6 text-gray-700 mr-3" fill="currentColor" viewBox="0 0 24 24">
                            <path
                                d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
                        </svg>
                        <h2 class="text-xl font-bold text-gray-800">Buku Terbaru</h2>
                    </div>
                    <div class="overflow-x-auto">
                        <table class="w-full">
                            <thead>
                                <tr class="bg-gray-50">
                                    <th
                                        class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        <div class="flex items-center">
                                            <svg class="w-4 h-4 mr-2" fill="currentColor" viewBox="0 0 24 24">
                                                <path d="M4 6h16v2H4zm0 5h16v2H4zm0 5h16v2H4z" />
                                            </svg>
                                            Judul
                                        </div>
                                    </th>
                                    <th
                                        class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        <div class="flex items-center">
                                            <svg class="w-4 h-4 mr-2" fill="currentColor" viewBox="0 0 24 24">
                                                <path
                                                    d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                                            </svg>
                                            Penulis
                                        </div>
                                    </th>
                                    <th
                                        class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        <div class="flex items-center">
                                            <svg class="w-4 h-4 mr-2" fill="currentColor" viewBox="0 0 24 24">
                                                <path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                                            </svg>
                                            Tahun
                                        </div>
                                    </th>
                                    <th
                                        class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        <div class="flex items-center">
                                            <svg class="w-4 h-4 mr-2" fill="currentColor" viewBox="0 0 24 24">
                                                <path
                                                    d="M7 4V2C7 1.45 7.45 1 8 1H16C16.55 1 17 1.45 17 2V4H20C20.55 4 21 4.45 21 5S20.55 6 20 6H19V19C19 20.1 18.1 21 17 21H7C5.9 21 5 20.1 5 19V6H4C3.45 6 3 5.55 3 5S3.45 4 4 4H7ZM9 3V4H15V3H9ZM7 6V19H17V6H7Z" />
                                            </svg>
                                            Stok
                                        </div>
                                    </th>
                                </tr>
                            </thead>
                            <tbody class="bg-white divide-y divide-gray-200">
                                <?php
                                $recent_books_query = "SELECT title, author, year_published, stock FROM books ORDER BY created_at DESC LIMIT 5";
                                $recent_books_result = $conn->query($recent_books_query);

                                if ($recent_books_result->num_rows > 0) {
                                    while ($book = $recent_books_result->fetch_assoc()) {
                                        echo "<tr class='hover:bg-gray-50'>";
                                        echo "<td class='px-6 py-4 whitespace-nowrap text-sm text-gray-900'>" . htmlspecialchars($book['title']) . "</td>";
                                        echo "<td class='px-6 py-4 whitespace-nowrap text-sm text-gray-600'>" . htmlspecialchars($book['author']) . "</td>";
                                        echo "<td class='px-6 py-4 whitespace-nowrap text-sm text-gray-600'>" . $book['year_published'] . "</td>";
                                        echo "<td class='px-6 py-4 whitespace-nowrap text-sm text-gray-600'>" . $book['stock'] . "</td>";
                                        echo "</tr>";
                                    }
                                } else {
                                    echo "<tr><td colspan='4' class='px-6 py-4 text-center text-gray-500'>Belum ada buku</td></tr>";
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- Recent Activities (for print report) -->
                <div class="bg-white rounded-lg shadow-sm p-6 mt-8">
                    <div class="flex items-center mb-4">
                        <svg class="w-6 h-6 text-gray-700 mr-3" fill="currentColor" viewBox="0 0 24 24">
                            <path
                                d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" />
                        </svg>
                        <h2 class="text-xl font-bold text-gray-800">Aktivitas Peminjaman Terbaru</h2>
                    </div>
                    <div class="overflow-x-auto">
                        <table class="w-full">
                            <thead>
                                <tr class="bg-gray-50">
                                    <th
                                        class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        <div class="flex items-center">
                                            <svg class="w-4 h-4 mr-2" fill="currentColor" viewBox="0 0 24 24">
                                                <path
                                                    d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                                            </svg>
                                            User
                                        </div>
                                    </th>
                                    <th
                                        class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        <div class="flex items-center">
                                            <svg class="w-4 h-4 mr-2" fill="currentColor" viewBox="0 0 24 24">
                                                <path
                                                    d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
                                            </svg>
                                            Buku
                                        </div>
                                    </th>
                                    <th
                                        class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        <div class="flex items-center">
                                            <svg class="w-4 h-4 mr-2" fill="currentColor" viewBox="0 0 24 24">
                                                <path
                                                    d="M8 7V3a1 1 0 012 0v4h4V3a1 1 0 012 0v4h2a1 1 0 011 1v11a1 1 0 01-1 1H6a1 1 0 01-1-1V8a1 1 0 011-1h2z" />
                                            </svg>
                                            Tanggal Pinjam
                                        </div>
                                    </th>
                                    <th
                                        class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        <div class="flex items-center">
                                            <svg class="w-4 h-4 mr-2" fill="currentColor" viewBox="0 0 24 24">
                                                <path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                                            </svg>
                                            Status
                                        </div>
                                    </th>
                                </tr>
                            </thead>
                            <tbody class="bg-white divide-y divide-gray-200">
                                <?php
                                $recent_borrowings_query = "SELECT u.username, b.title, br.borrow_date, br.status 
                                                          FROM borrowings br 
                                                          JOIN users u ON br.user_id = u.id 
                                                          JOIN books b ON br.book_id = b.id 
                                                          ORDER BY br.created_at DESC LIMIT 10";
                                $recent_borrowings_result = $conn->query($recent_borrowings_query);

                                if ($recent_borrowings_result->num_rows > 0) {
                                    while ($borrowing = $recent_borrowings_result->fetch_assoc()) {
                                        $status_class = '';
                                        $status_text = '';
                                        $status_icon = '';
                                        switch ($borrowing['status']) {
                                            case 'borrowed':
                                                $status_class = 'bg-blue-100 text-blue-800';
                                                $status_text = 'Dipinjam';
                                                $status_icon = '<svg class="w-4 h-4 mr-1" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>';
                                                break;
                                            case 'returned':
                                                $status_class = 'bg-green-100 text-green-800';
                                                $status_text = 'Dikembalikan';
                                                $status_icon = '<svg class="w-4 h-4 mr-1" fill="currentColor" viewBox="0 0 24 24"><path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>';
                                                break;
                                            case 'overdue':
                                                $status_class = 'bg-red-100 text-red-800';
                                                $status_text = 'Terlambat';
                                                $status_icon = '<svg class="w-4 h-4 mr-1" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/></svg>';
                                                break;
                                        }

                                        echo "<tr class='hover:bg-gray-50'>";
                                        echo "<td class='px-6 py-4 whitespace-nowrap text-sm text-gray-900'>" . htmlspecialchars($borrowing['username']) . "</td>";
                                        echo "<td class='px-6 py-4 whitespace-nowrap text-sm text-gray-600'>" . htmlspecialchars($borrowing['title']) . "</td>";
                                        echo "<td class='px-6 py-4 whitespace-nowrap text-sm text-gray-600'>" . date('d/m/Y', strtotime($borrowing['borrow_date'])) . "</td>";
                                        echo "<td class='px-6 py-4 whitespace-nowrap'>";
                                        echo "<span class='inline-flex items-center px-2 py-1 text-xs font-semibold rounded-full " . $status_class . "'>" . $status_icon . $status_text . "</span>";
                                        echo "</td>";
                                        echo "</tr>";
                                    }
                                } else {
                                    echo "<tr><td colspan='4' class='px-6 py-4 text-center text-gray-500'>Belum ada aktivitas peminjaman</td></tr>";
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- Print Signature Area (only visible when printing) -->
                <div class="print-signature">
                    <div style="margin-top: 80px;">
                        <p>Jakarta, <?php echo date('d/m/Y'); ?></p>
                        <p>Administrator Perpustakaan</p>
                        <br><br><br>
                        <p>(_________________________)</p>
                        <p><?php echo $_SESSION['username']; ?></p>
                    </div>
                </div>
            </main>
        </div>
    </div>
</body>

</html>