<?php
session_start();
require_once '../config.php';

// Cek apakah user adalah admin
check_admin();

$message = '';
$message_type = '';
$action = isset($_GET['action']) ? $_GET['action'] : 'list';
$user_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Handle form submissions
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['add_user'])) {
        $username = clean_input($_POST['username']);
        $email = clean_input($_POST['email']);
        $password = clean_input($_POST['password']);
        $confirm_password = clean_input($_POST['confirm_password']);
        $role = clean_input($_POST['role']);

        // Validasi input
        if (empty($username) || empty($email) || empty($password) || empty($confirm_password)) {
            $message = "Semua field harus diisi!";
            $message_type = "error";
        } elseif ($password != $confirm_password) {
            $message = "Password dan konfirmasi password tidak cocok!";
            $message_type = "error";
        } elseif (strlen($password) < 6) {
            $message = "Password minimal 6 karakter!";
            $message_type = "error";
        } else {
            // Cek apakah username atau email sudah ada
            $check_query = "SELECT id FROM users WHERE username = ? OR email = ?";
            $stmt = $conn->prepare($check_query);
            $stmt->bind_param("ss", $username, $email);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                $message = "Username atau email sudah terdaftar!";
                $message_type = "error";
            } else {
                // Insert user baru
                $hashed_password = hash_password($password);
                $insert_query = "INSERT INTO users (username, email, password, role) VALUES (?, ?, ?, ?)";
                $stmt = $conn->prepare($insert_query);
                $stmt->bind_param("ssss", $username, $email, $hashed_password, $role);

                if ($stmt->execute()) {
                    $message = "User berhasil ditambahkan!";
                    $message_type = "success";
                    $action = 'list';
                } else {
                    $message = "Gagal menambahkan user: " . $conn->error;
                    $message_type = "error";
                }
            }
        }
    }

    if (isset($_POST['update_user'])) {
        $id = (int)$_POST['id'];
        $username = clean_input($_POST['username']);
        $email = clean_input($_POST['email']);
        $password = clean_input($_POST['password']);
        $role = clean_input($_POST['role']);

        // Tidak bisa mengubah data diri sendiri
        if ($id == $_SESSION['user_id']) {
            $message = "Anda tidak bisa mengubah data sendiri melalui halaman ini!";
            $message_type = "error";
        } else {
            // Validasi input
            if (empty($username) || empty($email)) {
                $message = "Username dan email harus diisi!";
                $message_type = "error";
            } else {
                // Cek apakah username atau email sudah ada (kecuali untuk user yang sedang diedit)
                $check_query = "SELECT id FROM users WHERE (username = ? OR email = ?) AND id != ?";
                $stmt = $conn->prepare($check_query);
                $stmt->bind_param("ssi", $username, $email, $id);
                $stmt->execute();
                $result = $stmt->get_result();

                if ($result->num_rows > 0) {
                    $message = "Username atau email sudah digunakan user lain!";
                    $message_type = "error";
                } else {
                    // Update user
                    $success = false;

                    if (!empty($password)) {
                        // Update dengan password baru
                        if (strlen($password) < 6) {
                            $message = "Password minimal 6 karakter!";
                            $message_type = "error";
                        } else {
                            $hashed_password = hash_password($password);
                            $update_query = "UPDATE users SET username=?, email=?, password=?, role=? WHERE id=?";
                            $stmt = $conn->prepare($update_query);
                            $stmt->bind_param("ssssi", $username, $email, $hashed_password, $role, $id);
                            $success = $stmt->execute();
                        }
                    } else {
                        // Update tanpa mengubah password
                        $update_query = "UPDATE users SET username=?, email=?, role=? WHERE id=?";
                        $stmt = $conn->prepare($update_query);
                        $stmt->bind_param("sssi", $username, $email, $role, $id);
                        $success = $stmt->execute();
                    }

                    if ($success) {
                        $message = "User berhasil diupdate!";
                        $message_type = "success";
                        $action = 'list';
                    } elseif (!isset($message)) {
                        $message = "Gagal mengupdate user!";
                        $message_type = "error";
                    }
                }
            }
        }
    }

    if (isset($_POST['change_role'])) {
        $user_id = (int)$_POST['user_id'];
        $new_role = clean_input($_POST['new_role']);

        // Tidak bisa mengubah role diri sendiri
        if ($user_id == $_SESSION['user_id']) {
            $message = "Anda tidak bisa mengubah role sendiri!";
            $message_type = "error";
        } else {
            $update_query = "UPDATE users SET role = ? WHERE id = ?";
            $stmt = $conn->prepare($update_query);
            $stmt->bind_param("si", $new_role, $user_id);

            if ($stmt->execute()) {
                $message = "Role user berhasil diubah!";
                $message_type = "success";
            } else {
                $message = "Gagal mengubah role user: " . $conn->error;
                $message_type = "error";
            }
        }
    }
}

// Handle delete user
if (isset($_GET['delete']) && $_GET['delete'] > 0) {
    $delete_id = (int)$_GET['delete'];

    // Tidak bisa menghapus diri sendiri
    if ($delete_id == $_SESSION['user_id']) {
        $message = "Anda tidak bisa menghapus akun sendiri!";
        $message_type = "error";
    } else {
        $delete_query = "DELETE FROM users WHERE id = ?";
        $stmt = $conn->prepare($delete_query);
        $stmt->bind_param("i", $delete_id);

        if ($stmt->execute()) {
            $message = "User berhasil dihapus!";
            $message_type = "success";
        } else {
            $message = "Gagal menghapus user: " . $conn->error;
            $message_type = "error";
        }
    }
    $action = 'list';
}

// Get user data for edit
$user_data = null;
if ($action == 'edit' && $user_id > 0) {
    $edit_query = "SELECT * FROM users WHERE id = ?";
    $stmt = $conn->prepare($edit_query);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $user_data = $result->fetch_assoc();

    if (!$user_data) {
        $message = "User tidak ditemukan!";
        $message_type = "error";
        $action = 'list';
    } elseif ($user_data['id'] == $_SESSION['user_id']) {
        $message = "Anda tidak bisa mengedit data sendiri melalui halaman ini!";
        $message_type = "error";
        $action = 'list';
    }
}
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola User - Admin Perpustakaan</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link rel="stylesheet" href="../style-tailwind.css">
    <style>
    .user-row {
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    }

    .user-row:hover {
        transform: translateY(-1px);
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
    }

    @keyframes fadeIn {
        from {
            opacity: 0;
            transform: translateY(20px);
        }

        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    .animate-fade-in {
        animation: fadeIn 0.5s ease-out;
    }
    </style>
</head>

<body class="bg-gray-100">
    <div class="flex h-screen">
        <!-- Sidebar -->
        <div class="sidebar-gradient w-64 text-white flex flex-col sticky top-0 h-screen no-print">
            <div class="p-6 border-b border-white border-opacity-20">
                <h3 class="text-xl font-bold">📚 Admin Panel</h3>
            </div>
            <nav class="flex-1 px-4 py-6 space-y-2">
                <a href="dashboard.php"
                    class="flex items-center px-4 py-3 text-white hover:bg-white hover:bg-opacity-10 rounded-lg transition-colors">
                    📊 Dashboard
                </a>
                <a href="books.php"
                    class="flex items-center px-4 py-3 text-white hover:bg-white hover:bg-opacity-10 rounded-lg transition-colors">
                    📖 Kelola Buku
                </a>
                <a href="borrowings.php"
                    class="flex items-center px-4 py-3 text-white hover:bg-white hover:bg-opacity-10 rounded-lg transition-colors">
                    📋 Kelola Peminjaman
                </a>
                <a href="users.php"
                    class="flex items-center px-4 py-3 text-white bg-white bg-opacity-20 rounded-lg font-medium">
                    👥 Kelola User
                </a>
                <a href="../logout.php"
                    class="flex items-center px-4 py-3 text-white hover:bg-white hover:bg-opacity-10 rounded-lg transition-colors">
                    🚪 Logout
                </a>
            </nav>
        </div>

        <!-- Main Content -->
        <div class="flex-1 flex flex-col overflow-hidden">
            <!-- Header -->
            <div class="bg-white shadow-sm border-b border-gray-200 px-6 py-4">
                <div class="flex justify-between items-center">
                    <h1 class="text-2xl font-bold text-gray-900">
                        <?php
                        if ($action == 'add') echo 'Tambah User Baru';
                        elseif ($action == 'edit') echo 'Edit User';
                        else echo 'Kelola User';
                        ?>
                    </h1>
                    <div class="flex items-center space-x-3">
                        <?php if ($action == 'list'): ?>
                        <a href="?action=add"
                            class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition-colors flex items-center space-x-2">
                            <span>➕</span>
                            <span>Tambah User</span>
                        </a>
                        <?php endif; ?>
                        <div
                            class="w-8 h-8 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center text-white font-bold text-sm">
                            <?php echo strtoupper(substr($_SESSION['username'], 0, 1)); ?>
                        </div>
                        <div class="text-sm">
                            <div class="font-medium text-gray-900"><?php echo $_SESSION['username']; ?></div>
                            <div class="text-gray-500">Administrator</div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Content -->
            <div class="flex-1 overflow-auto p-6">
                <?php if (!empty($message)): ?>
                <script>
                document.addEventListener('DOMContentLoaded', function() {
                    Swal.fire({
                        icon: '<?php echo $message_type == "success" ? "success" : "error"; ?>',
                        title: '<?php echo $message_type == "success" ? "Berhasil!" : "Error!"; ?>',
                        text: '<?php echo addslashes($message); ?>',
                        confirmButtonColor: '<?php echo $message_type == "success" ? "#10b981" : "#ef4444"; ?>',
                        customClass: {
                            popup: 'rounded-2xl shadow-2xl',
                            confirmButton: 'font-semibold px-6 py-3 rounded-lg'
                        },
                        backdrop: `rgba(0,0,0,0.4)`
                    });
                });
                </script>
                <?php endif; ?>

                <?php if ($action == 'add'): ?>
                <!-- Form Tambah User -->
                <div class="bg-white rounded-lg shadow-sm p-6">
                    <div class="mb-6">
                        <h2 class="text-lg font-medium text-gray-900">Tambah User Baru</h2>
                        <p class="text-sm text-gray-600 mt-1">Isi form berikut untuk menambah user baru</p>
                    </div>

                    <form method="POST" class="space-y-4">
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Username</label>
                                <input type="text" name="username" required
                                    class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                                    placeholder="Username unik">
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Email</label>
                                <input type="email" name="email" required
                                    class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                                    placeholder="email@domain.com">
                            </div>
                        </div>

                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Password</label>
                                <input type="password" name="password" required
                                    class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                                    placeholder="Minimal 6 karakter">
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Konfirmasi Password</label>
                                <input type="password" name="confirm_password" required
                                    class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                                    placeholder="Ulangi password">
                            </div>
                        </div>

                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Role</label>
                            <select name="role" required
                                class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                                <option value="user">User</option>
                                <option value="admin">Admin</option>
                            </select>
                        </div>

                        <div class="flex space-x-3 pt-4">
                            <button type="submit" name="add_user"
                                class="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-lg transition-colors">
                                Tambah User
                            </button>
                            <a href="?action=list"
                                class="bg-gray-500 hover:bg-gray-600 text-white px-6 py-2 rounded-lg transition-colors">
                                Batal
                            </a>
                        </div>
                    </form>
                </div>

                <?php elseif ($action == 'edit' && $user_data): ?>
                <!-- Form Edit User -->
                <div class="bg-white rounded-lg shadow-sm p-6">
                    <div class="mb-6">
                        <h2 class="text-lg font-medium text-gray-900">Edit User</h2>
                        <p class="text-sm text-gray-600 mt-1">Edit data user:
                            <strong><?php echo htmlspecialchars($user_data['username']); ?></strong>
                        </p>
                    </div>

                    <form method="POST" class="space-y-4">
                        <input type="hidden" name="id" value="<?php echo $user_data['id']; ?>">

                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Username</label>
                                <input type="text" name="username" required
                                    value="<?php echo htmlspecialchars($user_data['username']); ?>"
                                    class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Email</label>
                                <input type="email" name="email" required
                                    value="<?php echo htmlspecialchars($user_data['email']); ?>"
                                    class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                            </div>
                        </div>

                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Password Baru</label>
                                <input type="password" name="password"
                                    class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                                    placeholder="Kosongkan jika tidak ingin mengubah">
                                <p class="text-xs text-gray-500 mt-1">Kosongkan jika tidak ingin mengubah password</p>
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Role</label>
                                <select name="role" required
                                    class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                                    <option value="user" <?php echo $user_data['role'] == 'user' ? 'selected' : ''; ?>>
                                        User</option>
                                    <option value="admin"
                                        <?php echo $user_data['role'] == 'admin' ? 'selected' : ''; ?>>Admin</option>
                                </select>
                            </div>
                        </div>

                        <div class="flex space-x-3 pt-4">
                            <button type="submit" name="update_user"
                                class="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-lg transition-colors">
                                Update User
                            </button>
                            <a href="?action=list"
                                class="bg-gray-500 hover:bg-gray-600 text-white px-6 py-2 rounded-lg transition-colors">
                                Batal
                            </a>
                        </div>
                    </form>
                </div>

                <?php else: ?>
                <!-- List Users -->
                <div class="bg-white rounded-lg shadow-sm overflow-hidden">
                    <div class="overflow-x-auto">
                        <table class="min-w-full divide-y divide-gray-200">
                            <thead class="bg-gray-50">
                                <tr>
                                    <th
                                        class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Username</th>
                                    <th
                                        class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Email</th>
                                    <th
                                        class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Role</th>
                                    <th
                                        class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Bergabung</th>
                                    <th
                                        class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Aksi</th>
                                </tr>
                            </thead>
                            <tbody class="bg-white divide-y divide-gray-200">
                                <?php
                                    $users_query = "SELECT * FROM users ORDER BY created_at DESC";
                                    $users_result = $conn->query($users_query);

                                    if ($users_result->num_rows > 0) {
                                        while ($user = $users_result->fetch_assoc()) {
                                            echo "<tr class='user-row hover:bg-gray-50'>";
                                            echo "<td class='px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900'>" . htmlspecialchars($user['username']) . "</td>";
                                            echo "<td class='px-6 py-4 whitespace-nowrap text-sm text-gray-500'>" . htmlspecialchars($user['email']) . "</td>";
                                            echo "<td class='px-6 py-4 whitespace-nowrap text-sm text-gray-500'>";

                                            // Form untuk mengubah role
                                            if ($user['id'] != $_SESSION['user_id']) {
                                                echo "<form method='POST' class='inline'>";
                                                echo "<input type='hidden' name='user_id' value='" . $user['id'] . "'>";
                                                echo "<select name='new_role' onchange='confirmRoleChange(this, \"" . addslashes($user['username']) . "\")' class='text-sm border border-gray-300 rounded px-2 py-1 focus:outline-none focus:ring-2 focus:ring-blue-500'>";
                                                echo "<option value='user'" . ($user['role'] == 'user' ? ' selected' : '') . ">User</option>";
                                                echo "<option value='admin'" . ($user['role'] == 'admin' ? ' selected' : '') . ">Admin</option>";
                                                echo "</select>";
                                                echo "<input type='hidden' name='change_role' value='1'>";
                                                echo "</form>";
                                            } else {
                                                $badge_class = $user['role'] == 'admin' ? 'bg-purple-100 text-purple-800' : 'bg-blue-100 text-blue-800';
                                                echo "<span class='inline-flex px-2 py-1 text-xs font-semibold rounded-full " . $badge_class . "'>" . ucfirst($user['role']) . " (Anda)</span>";
                                            }

                                            echo "</td>";
                                            echo "<td class='px-6 py-4 whitespace-nowrap text-sm text-gray-500'>" . date('d/m/Y H:i', strtotime($user['created_at'])) . "</td>";
                                            echo "<td class='px-6 py-4 whitespace-nowrap text-sm font-medium'>";

                                            if ($user['id'] != $_SESSION['user_id']) {
                                                echo "<div class='flex space-x-2'>";
                                                echo "<button onclick='editUser(" . $user['id'] . ")' class='bg-yellow-100 hover:bg-yellow-200 text-yellow-600 hover:text-yellow-800 px-3 py-1 rounded-lg flex items-center space-x-1 transition-colors'>";
                                                echo "<svg class='w-4 h-4' fill='currentColor' viewBox='0 0 24 24'><path d='M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04c.39-.39.39-1.02 0-1.41l-2.34-2.34c-.39-.39-1.02-.39-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z'/></svg>";
                                                echo "<span>Edit</span></button>";
                                                echo "<button onclick='confirmDeleteUser(" . $user['id'] . ", \"" . addslashes($user['username']) . "\")' class='bg-red-100 hover:bg-red-200 text-red-600 hover:text-red-800 px-3 py-1 rounded-lg flex items-center space-x-1 transition-colors'>";
                                                echo "<svg class='w-4 h-4' fill='currentColor' viewBox='0 0 24 24'><path d='M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z'/></svg>";
                                                echo "<span>Hapus</span></button>";
                                                echo "</div>";
                                            } else {
                                                echo "<span class='text-gray-400'>-</span>";
                                            }

                                            echo "</td>";
                                            echo "</tr>";
                                        }
                                    } else {
                                        echo "<tr><td colspan='6' class='px-6 py-4 text-center text-sm text-gray-500'>Belum ada user</td></tr>";
                                    }
                                    ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <div class="mt-6 bg-white rounded-lg shadow-sm p-6">
                    <h3 class="text-lg font-medium text-gray-900 mb-4">Informasi</h3>
                    <ul class="space-y-2 text-sm text-gray-600">
                        <li class="flex items-start">
                            <span class="w-2 h-2 bg-blue-500 rounded-full mt-2 mr-3 flex-shrink-0"></span>
                            Anda tidak dapat menghapus atau mengubah data akun sendiri
                        </li>
                        <li class="flex items-start">
                            <span class="w-2 h-2 bg-blue-500 rounded-full mt-2 mr-3 flex-shrink-0"></span>
                            User dengan role "admin" dapat mengakses panel admin
                        </li>
                        <li class="flex items-start">
                            <span class="w-2 h-2 bg-blue-500 rounded-full mt-2 mr-3 flex-shrink-0"></span>
                            User dengan role "user" hanya dapat mengakses dashboard user
                        </li>
                        <li class="flex items-start">
                            <span class="w-2 h-2 bg-blue-500 rounded-full mt-2 mr-3 flex-shrink-0"></span>
                            Password minimal 6 karakter saat membuat atau mengubah user
                        </li>
                    </ul>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script>
    // Function to edit user
    function editUser(userId) {
        window.location.href = '?action=edit&id=' + userId;
    }

    // Function to confirm user deletion
    function confirmDeleteUser(userId, username) {
        Swal.fire({
            title: '<div class="flex items-center gap-2"><span class="text-2xl">👤</span><span>Konfirmasi Hapus User</span></div>',
            html: `
                    <div class="text-center p-4">
                        <div class="mb-4 p-4 bg-red-50 border border-red-200 rounded-xl">
                            <p class="text-gray-700 mb-2">Apakah Anda yakin ingin menghapus user:</p>
                            <p class="font-bold text-red-600 text-lg">"${username}"</p>
                        </div>
                        
                        <div class="text-sm text-red-600 bg-red-50 p-3 rounded-lg border border-red-200">
                            <p class="font-medium text-red-700 mb-1">⚠️ Peringatan:</p>
                            <ul class="text-left list-disc list-inside space-y-1">
                                <li>Semua data peminjaman user akan tetap tersimpan</li>
                                <li>User tidak akan bisa login lagi</li>
                                <li>Aksi ini tidak dapat dibatalkan</li>
                            </ul>
                        </div>
                    </div>
                `,
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: '<i class="mr-2">🗑️</i> Ya, Hapus User!',
            cancelButtonText: '<i class="mr-2">❌</i> Batal',
            confirmButtonColor: '#dc2626',
            cancelButtonColor: '#6b7280',
            reverseButtons: true,
            customClass: {
                popup: 'rounded-2xl shadow-2xl',
                confirmButton: 'font-semibold px-6 py-3 rounded-lg',
                cancelButton: 'font-semibold px-6 py-3 rounded-lg'
            },
            backdrop: `rgba(0,0,0,0.4)`
        }).then((result) => {
            if (result.isConfirmed) {
                // Show loading
                Swal.fire({
                    title: '<div class="flex items-center gap-2"><span class="text-2xl">⏳</span><span>Menghapus User...</span></div>',
                    html: `
                            <div class="text-center p-4">
                                <div class="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-red-600 mb-4"></div>
                                <p class="text-gray-600">Sedang menghapus user "${username}"</p>
                            </div>
                        `,
                    allowOutsideClick: false,
                    allowEscapeKey: false,
                    showConfirmButton: false,
                    customClass: {
                        popup: 'rounded-2xl shadow-2xl'
                    },
                    backdrop: `rgba(0,0,0,0.6)`
                });

                // Redirect after a small delay
                setTimeout(() => {
                    window.location.href = '?delete=' + userId;
                }, 1000);
            }
        });
    }

    // Function to confirm role change
    function confirmRoleChange(selectElement, username) {
        const newRole = selectElement.value;
        const form = selectElement.closest('form');
        const currentRole = selectElement.querySelector('option:not([value="' + newRole + '"])').value;

        // Reset to original value first
        selectElement.value = currentRole;

        Swal.fire({
            title: '<div class="flex items-center gap-2"><span class="text-2xl">🔄</span><span>Konfirmasi Ubah Role</span></div>',
            html: `
                    <div class="text-center p-4">
                        <div class="mb-4 p-4 bg-blue-50 border border-blue-200 rounded-xl">
                            <p class="text-gray-700 mb-2">Ubah role user <strong>"${username}"</strong> menjadi:</p>
                            <p class="font-bold text-blue-600 text-lg">${newRole.toUpperCase()}</p>
                        </div>
                        
                        <div class="text-sm text-gray-600 bg-gray-50 p-3 rounded-lg">
                            <p class="font-medium text-gray-700 mb-1">ℹ️ Informasi:</p>
                            <ul class="text-left list-disc list-inside space-y-1">
                                <li><strong>Admin:</strong> Dapat mengakses panel admin</li>
                                <li><strong>User:</strong> Hanya dapat mengakses dashboard user</li>
                                <li>Perubahan akan berlaku pada login berikutnya</li>
                            </ul>
                        </div>
                    </div>
                `,
            icon: 'question',
            showCancelButton: true,
            confirmButtonText: '<i class="mr-2">✅</i> Ya, Ubah Role!',
            cancelButtonText: '<i class="mr-2">❌</i> Batal',
            confirmButtonColor: '#2563eb',
            cancelButtonColor: '#6b7280',
            reverseButtons: true,
            customClass: {
                popup: 'rounded-2xl shadow-2xl',
                confirmButton: 'font-semibold px-6 py-3 rounded-lg',
                cancelButton: 'font-semibold px-6 py-3 rounded-lg'
            },
            backdrop: `rgba(0,0,0,0.4)`
        }).then((result) => {
            if (result.isConfirmed) {
                // Show loading
                Swal.fire({
                    title: '<div class="flex items-center gap-2"><span class="text-2xl">⏳</span><span>Mengubah Role...</span></div>',
                    html: `
                            <div class="text-center p-4">
                                <div class="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mb-4"></div>
                                <p class="text-gray-600">Sedang mengubah role "${username}" menjadi ${newRole}</p>
                            </div>
                        `,
                    allowOutsideClick: false,
                    allowEscapeKey: false,
                    showConfirmButton: false,
                    customClass: {
                        popup: 'rounded-2xl shadow-2xl'
                    },
                    backdrop: `rgba(0,0,0,0.6)`
                });

                // Set the new value and submit after delay
                setTimeout(() => {
                    selectElement.value = newRole;
                    form.submit();
                }, 1000);
            }
        });
    }

    // Add initialization when page loads
    document.addEventListener('DOMContentLoaded', function() {
        // Add hover effects to user rows
        const userRows = document.querySelectorAll('.user-row');
        userRows.forEach(row => {
            row.addEventListener('mouseenter', function() {
                this.style.backgroundColor = '#f9fafb';
            });
            row.addEventListener('mouseleave', function() {
                this.style.backgroundColor = '';
            });
        });
    });
    </script>
</body>

</html>